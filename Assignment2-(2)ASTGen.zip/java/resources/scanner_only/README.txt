In case your scanner does not work properly, you can use the class files in
this subdirectory instead. The provided classfiles are Scanner.class and
MiniC.class. You must use *both* classfiles, otherwise the scanner won’t work.

See the Assignment 2 specification on how to compile with gradle to use
these provided classfiles.
