In case your scanner and parser do not work properly, you can use the class
files in this subdirectory instead. The provided classfiles are Scanner.class,
Parser.class and MiniC.class. You must use *all* classfiles, otherwise scanner
and parser won’t work.

See the Assignment 2 specification on how to compile with gradle to use
these provided classfiles.
