#ifndef __STMT_H__
#define __STMT_H__

#include "../Scanner/SourcePos.hh"
#include "AST.hh"

class Stmt: public AST
{
public:
    Stmt (SourcePos pos):AST(pos){}
};

#endif