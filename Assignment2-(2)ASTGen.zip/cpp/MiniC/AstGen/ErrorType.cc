#include "ErrorType.hh"
#include <iostream>

using namespace std;

void ErrorType::accept(Visitor *v)
{
    v->visit(this);
}

bool ErrorType::Tequal(Type *t)
{
    if (t!= nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && typeid(t) == typeid(ErrorType*));
}

bool ErrorType::AssignableTo(Type *t)
{
    return true;
}