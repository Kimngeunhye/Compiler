#ifndef __BOOL_EXPR_H__
#define __BOOL_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class BoolExpr: public Expr
{
public:
    BoolLiteral* astBL;
    BoolExpr (BoolLiteral* astBL, SourcePos pos):Expr(pos){this->astBL = astBL;}
    virtual void accept(Visitor *v);
};

#endif