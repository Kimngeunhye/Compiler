#ifndef __AST_H__
#define __AST_H__

#include "../Scanner/SourcePos.hh"

class Visitor;

class AST
{
public:
    SourcePos* pos;
    AST (SourcePos pos);
    SourcePos getPosition();
    virtual void accept(Visitor *v) = 0;
};

#endif