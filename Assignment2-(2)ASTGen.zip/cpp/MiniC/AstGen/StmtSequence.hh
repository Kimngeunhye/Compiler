#ifndef __STMT_SEQUENCE_H__
#define __STMT_SEQUENCE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Stmt.hh"

class StmtSequence: public Stmt
{
public:
    Stmt *s1AST, *s2AST;
    StmtSequence (Stmt *s1AST, Stmt *s2AST, SourcePos pos):Stmt(pos){
        this->s1AST = s1AST;
        this->s2AST = s2AST;
    }
    virtual void accept(Visitor *v);
};

#endif