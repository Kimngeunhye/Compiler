#include "VarExpr.hh"

void VarExpr::accept(Visitor *v)
{
    v->visit(this);
}