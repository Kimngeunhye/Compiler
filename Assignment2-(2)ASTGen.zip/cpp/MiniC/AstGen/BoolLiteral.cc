#include "BoolLiteral.hh"

void BoolLiteral::accept(Visitor *v)
{
    v->visit(this);
}