#include "StmtSequence.hh"

void StmtSequence::accept(Visitor *v)
{
    v->visit(this);
}