#include "Program.hh"

void Program::accept(Visitor *v)
{
    v->visit(this);
}