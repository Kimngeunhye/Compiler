#ifndef __EXPR_H__
#define __EXPR_H__

#include "../Scanner/SourcePos.hh"
#include "AST.hh"
#include "Type.hh"

class Expr: public AST
{
public:
    Type *type;
    Expr(SourcePos pos):AST(pos){};
};

#endif