#include "IntType.hh"
#include <iostream>

using namespace std;

void IntType::accept(Visitor *v)
{
    v->visit(this);
}

bool IntType::Tequal(Type *t)
{
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && typeid(t) == typeid(IntType*));
}

bool IntType::AssignableTo(Type *t)
{
    //IntType assignable to t ?
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && ((typeid(t) == typeid(IntType*)) || (typeid(t) == typeid(FloatType*))));
}