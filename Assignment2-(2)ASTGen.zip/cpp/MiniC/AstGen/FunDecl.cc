#include "FunDecl.hh"

void FunDecl::accept(Visitor *v)
{
    v->visit(this);
}