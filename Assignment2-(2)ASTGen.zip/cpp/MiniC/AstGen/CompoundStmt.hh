#ifndef __COMPOUND_STMT_H__
#define __COMPOUND_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Stmt.hh"
#include "Decl.hh"

class CompoundStmt: public Stmt
{
public:
    Decl *astDecl;
    Stmt *astStmt;
    CompoundStmt(Decl *astDecl, Stmt *astStmt, SourcePos pos):Stmt(pos){
        this->astDecl = astDecl;
        this->astStmt = astStmt;
    }
    virtual void accept(Visitor *v);
};

#endif