#ifndef __OPERATOR_H__
#define __OPERATOR_H__

#include "Terminal.hh"
#include "Visitor.hh"
#include "Type.hh"
#include <string>

using namespace std;

class Operator: public Terminal
{
public:
    Type *type;
    Operator(string Lexeme, SourcePos pos):Terminal(pos)
    {
        this->Lexeme = Lexeme;
        this->type = nullptr;
    }
    virtual void accept(Visitor *v);
};

#endif