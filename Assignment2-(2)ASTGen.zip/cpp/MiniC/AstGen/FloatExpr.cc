#include "FloatExpr.hh"

void FloatExpr::accept(Visitor *v)
{
    v->visit(this);
}