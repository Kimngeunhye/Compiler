#ifndef __FLOAT_EXPR_H__
#define __FLOAT_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "FloatLiteral.hh"

class FloatExpr: public Expr
{
public:
    FloatLiteral *astFL;
    FloatExpr(FloatLiteral *astFL, SourcePos pos):Expr(pos){
        this->astFL = astFL;
    }
    virtual void accept(Visitor *v);
};

#endif