#ifndef __ARRAY_EXPR_H__
#define __ARRAY_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class ArrayExpr: public Expr
{
public:
    Expr* idAST;
    Expr* indexAST;
    ArrayExpr (Expr* idAST, Expr *indexAST, SourcePos pos):Expr(pos)
    {
        this->idAST = idAST;
        this->indexAST = indexAST;
    }
    virtual void accept(Visitor *v);
};

#endif