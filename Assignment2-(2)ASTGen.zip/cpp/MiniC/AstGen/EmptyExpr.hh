#ifndef __EMPTY_EXPR_H__
#define __EMPTY_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class EmptyExpr: public Expr
{
public:
    EmptyExpr (SourcePos pos):Expr(pos){}
    virtual void accept(Visitor *v);
};

#endif