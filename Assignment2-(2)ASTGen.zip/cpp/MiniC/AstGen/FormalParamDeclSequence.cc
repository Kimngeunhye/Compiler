#include "FormalParamDeclSequence.hh"

void FormalParamDeclSequence::accept(Visitor *v)
{
    v->visit(this);
}