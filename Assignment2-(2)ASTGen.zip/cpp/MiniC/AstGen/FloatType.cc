#include "FloatType.hh"
#include <iostream>

using namespace std;

void FloatType::accept(Visitor *v)
{
    v->visit(this);
}


bool FloatType::Tequal(Type *t)
{
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && typeid(t) == typeid(FloatType*));
}

bool FloatType::AssignableTo(Type *t)
{
    //FloatType assignable to t ?
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && (typeid(t) == typeid(FloatType*)));
}