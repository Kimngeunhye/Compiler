#ifndef __ASSIGN_STMT_H__
#define __ASSIGN_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Stmt.hh"

class AssignStmt: public Stmt
{
public:
    Expr *lAST;
    Expr *rAST;

    AssignStmt (Expr *lAST, Expr *rAST, SourcePos pos):Stmt(pos)
    {
        this->lAST = lAST;
        this->rAST = rAST;
    }
    virtual void accept(Visitor *v);
};

#endif