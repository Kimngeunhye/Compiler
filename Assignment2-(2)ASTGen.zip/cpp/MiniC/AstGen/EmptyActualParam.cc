#include "EmptyActualParam.hh"

void EmptyActualParam::accept(Visitor *v)
{
    v->visit(this);
}