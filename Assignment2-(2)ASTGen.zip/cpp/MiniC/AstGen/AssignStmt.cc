#include "AssignStmt.hh"

void AssignStmt::accept(Visitor *v)
{
    v->visit(this);
}