#ifndef __CALL_EXPR_H__
#define __CALL_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "IDentifier.hh"

class CallExpr: public Expr
{
public:
    IDentifier *idAST;
    Expr *paramAST;
    CallExpr(IDentifier *idAST, Expr *paramAST, SourcePos pos):Expr(pos){
        this->idAST = idAST;
        this->paramAST = paramAST;}
    virtual void accept(Visitor *v);
};

#endif