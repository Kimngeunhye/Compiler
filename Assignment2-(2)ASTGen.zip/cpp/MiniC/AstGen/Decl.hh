#ifndef __DECL_H__
#define __DECL_H__

#include "../Scanner/SourcePos.hh"
#include "AST.hh"

class Decl: public AST
{
public:
    Decl(SourcePos pos):AST(pos){}
};

#endif