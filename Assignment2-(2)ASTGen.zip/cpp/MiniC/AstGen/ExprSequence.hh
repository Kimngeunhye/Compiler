#ifndef __EXPR_SEQUENCE_H__
#define __EXPR_SEQUENCE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class ExprSequence: public Expr
{
public:
    Expr *lAST, *rAST;
    ExprSequence(Expr *lAST, Expr *rAST, SourcePos pos):Expr(pos){
        this->lAST = lAST;
        this->rAST = rAST;        
    }
    virtual void accept(Visitor *v);
};

#endif