#include "WhileStmt.hh"

void WhileStmt::accept(Visitor *v)
{
    v->visit(this);
}