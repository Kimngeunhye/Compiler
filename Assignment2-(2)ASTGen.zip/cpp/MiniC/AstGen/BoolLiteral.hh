#ifndef __BOOL_LITERAL_H__
#define __BOOL_LITERAL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Terminal.hh"
#include <string>

using namespace std;

class BoolLiteral: public Terminal
{
public:
    BoolLiteral (string Lexeme, SourcePos pos):Terminal(pos){this->Lexeme = Lexeme;}
    virtual void accept(Visitor *v);
};

#endif