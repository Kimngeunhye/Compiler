#include "EmptyStmt.hh"

void EmptyStmt::accept(Visitor *v)
{
    v->visit(this);
}