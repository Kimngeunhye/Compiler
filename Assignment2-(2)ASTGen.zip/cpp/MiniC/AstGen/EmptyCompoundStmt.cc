#include "EmptyCompoundStmt.hh"

void EmptyCompoundStmt::accept(Visitor *v)
{
    v->visit(this);
}