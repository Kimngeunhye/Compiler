#include "StringLiteral.hh"

void StringLiteral::accept(Visitor *v)
{
    v->visit(this);
}