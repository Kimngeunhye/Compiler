#ifndef __ACTUAL_PARAM_H__
#define __ACTUAL_PARAM_H__

#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Visitor.hh"

class ActualParam: public Expr {
public:
    Expr* pAST;
    ActualParam (Expr* pAST, SourcePos pos):Expr(pos){this->pAST = pAST;};
    virtual void accept(Visitor *v);
};

#endif