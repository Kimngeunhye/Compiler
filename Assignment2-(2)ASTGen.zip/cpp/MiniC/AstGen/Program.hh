#ifndef __PROGRAM_H__
#define __PROGRAM_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "AST.hh"
#include "Decl.hh"

class Program: public AST
{
public:
    Decl *D;
    Program (Decl *D, SourcePos pos):AST(pos){this->D = D;}
    virtual void accept(Visitor *v);
};

#endif