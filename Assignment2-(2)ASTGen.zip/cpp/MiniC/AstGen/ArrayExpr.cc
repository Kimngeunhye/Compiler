#include "ArrayExpr.hh"

void ArrayExpr::accept(Visitor *v)
{
    v->visit(this);
}