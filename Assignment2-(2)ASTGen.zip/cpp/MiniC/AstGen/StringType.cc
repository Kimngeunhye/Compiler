#include "StringType.hh"

bool StringType::Tequal (Type *t)
{
    if (t != nullptr && (typeid(t) == typeid(ErrorType*)))
        return true;
    else
        return (t != nullptr && (typeid(t) == typeid(StringType*)));
}

bool StringType::AssignableTo (Type *t)
{
    if (t != nullptr && (typeid(t) == typeid(ErrorType*)))
        return true;
    else
        return (t != nullptr && (typeid(t) == typeid(StringType*)));
}

void StringType::accept(Visitor *v)
{
    v->visit(this);
}