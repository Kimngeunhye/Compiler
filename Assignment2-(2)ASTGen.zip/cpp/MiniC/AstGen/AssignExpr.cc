#include "AssignExpr.hh"

void AssignExpr::accept(Visitor *v)
{
    v->visit(this);
}