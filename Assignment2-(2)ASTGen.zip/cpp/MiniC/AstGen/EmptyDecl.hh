#ifndef __EMPTY_DECL_H__
#define __EMPTY_DECL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Decl.hh"

class EmptyDecl: public Decl
{
public:
    EmptyDecl(SourcePos pos):Decl(pos){}
    virtual void accept(Visitor *v);
};

#endif