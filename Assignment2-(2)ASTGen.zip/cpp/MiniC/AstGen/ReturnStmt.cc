#include "ReturnStmt.hh"

void ReturnStmt::accept(Visitor *v)
{
    v->visit(this);
}