#ifndef __ARRAY_TYPE_H__
#define __ARRAY_TYPE_H__

#include "../Scanner/SourcePos.hh"
#include "Visitor.hh"
#include "Type.hh"
#include "Expr.hh"
#include "IntExpr.hh"
#include <cassert>

using namespace std;

class ArrayType: public Type
{
public:
    Type *astType;
    Expr *astExpr;

    ArrayType (Type *astType, Expr *astExpr, SourcePos pos):Type(pos)
    {
        this->astType = astType;
        this->astExpr = astExpr;
    }
    virtual void accept(Visitor *v);
    
    bool    Tequal (Type *t);
    bool    AssignableTo (Type *t);
    int     GetRange();
};

#endif