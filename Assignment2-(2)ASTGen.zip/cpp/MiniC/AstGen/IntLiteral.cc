#include "IntLiteral.hh"

void IntLiteral::accept(Visitor *v)
{
    v->visit(this);
}

int IntLiteral::GetValue()
{
    return value;
}