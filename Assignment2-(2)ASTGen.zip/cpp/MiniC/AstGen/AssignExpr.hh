#ifndef __ASSIGN_EXPR_H__
#define __ASSIGN_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class AssignExpr: public Expr
{
public:
    Expr *lAST;
    Expr *rAST;

    AssignExpr (Expr *lAST, Expr *rAST, SourcePos pos):Expr(pos)
    {
        this->lAST = lAST;
        this->rAST = rAST;
    }
    virtual void accept(Visitor *v);
};

#endif