#include "DeclSequence.hh"

Decl* DeclSequence::GetLeftSubtree()
{
    return D1;
}

Decl* DeclSequence::GetRightSubtree()
{
    return D2;
}

void DeclSequence::SetLeftSubtree(Decl *D)
{
    D1 = D;
}

void DeclSequence::SetRightSubtree(Decl *D)
{
    D2 = D;
}

DeclSequence* DeclSequence::GetRightmostDeclSequenceNode()
{
    assert(D2 != nullptr);
    if (typeid(D2) == typeid(this)){
        return ((DeclSequence *)D2)->GetRightmostDeclSequenceNode();
    }
    else{
        return this;
    }
}

void DeclSequence::accept(Visitor *v)
{
    v->visit(this);
}