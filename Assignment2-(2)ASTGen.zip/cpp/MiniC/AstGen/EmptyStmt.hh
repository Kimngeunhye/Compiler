#ifndef __EMPTY_STMT_H__
#define __EMPTY_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Stmt.hh"

class EmptyStmt: public Stmt
{
public:
    EmptyStmt (SourcePos pos):Stmt(pos){}
    virtual void accept(Visitor *v);
};

#endif