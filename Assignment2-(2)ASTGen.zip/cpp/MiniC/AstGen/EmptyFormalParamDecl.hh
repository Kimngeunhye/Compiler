#ifndef __EMPTY_FORMAL_PARAM_DECL_H__
#define __EMPTY_FORMAL_PARAM_DECL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "FormalParamDecl.hh"

class EmptyFormalParamDecl: public FormalParamDecl
{
public:
    EmptyFormalParamDecl (SourcePos pos): FormalParamDecl(nullptr, nullptr, pos){}
    virtual void accept(Visitor *v);
};

#endif