#ifndef __STRING_TYPE_H__
#define __STRING_TYPE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Type.hh"
#include <string>

using namespace std;

class StringType: public Type
{
public:
    StringType (SourcePos pos):Type(pos){}

    bool    Tequal (Type *t);
    bool    AssignableTo (Type *t);

    virtual void accept(Visitor *v);
};

#endif