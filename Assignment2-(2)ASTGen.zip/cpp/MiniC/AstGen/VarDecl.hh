#ifndef __VAR_DECL_H__
#define __VAR_DECL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Decl.hh"
#include "Type.hh"
#include "Expr.hh"
#include "IDentifier.hh"

class VarDecl: public Decl
{
public:
    Type *tAST;
    IDentifier *idAST;
    Expr *eAST;
    VarDecl (Type *tAST, IDentifier *idAST, Expr *eAST, SourcePos pos):Decl(pos){
        this->tAST = tAST;
        this->idAST = idAST;
        this->eAST = eAST;
    }
    virtual void accept(Visitor *v);
};

#endif