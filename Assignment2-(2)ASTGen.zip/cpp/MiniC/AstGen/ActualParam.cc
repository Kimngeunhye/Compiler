#include "ActualParam.hh"

void ActualParam::accept(Visitor *v){
    v->visit(this);
}
