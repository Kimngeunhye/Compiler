#ifndef __FLOAT_TYPE_H__
#define __FLOAT_TYPE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Type.hh"

class FloatType: public Type
{
public:
    FloatType(SourcePos pos):Type(pos){}
    virtual void accept(Visitor *v);
    bool Tequal(Type *t);
    bool AssignableTo(Type *t);
};


#endif