#ifndef __WHILE_STMT_H__
#define __WHILE_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Stmt.hh"
#include "Expr.hh"

class WhileStmt: public Stmt
{
public:
    Expr *eAST;
    Stmt *stmtAST;
    WhileStmt (Expr *eAST, Stmt *stmtAST, SourcePos pos):Stmt(pos){
        this->eAST = eAST;
        this->stmtAST = stmtAST;
    }
    virtual void accept(Visitor *v);
};

#endif