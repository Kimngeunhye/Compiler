#ifndef __DECL_SEQUENCE_H__
#define __DECL_SEQUENCE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Decl.hh"
#include <typeinfo>
#include <cassert>

class DeclSequence: public Decl
{
public:
    Decl *D1, *D2;
    DeclSequence(Decl *d1AST, Decl *d2AST, SourcePos pos):Decl(pos){
        this->D1 = d1AST;
        this->D2 = d2AST;
    }
    Decl* GetLeftSubtree();
    Decl* GetRightSubtree();
    void SetLeftSubtree(Decl *D);
    void SetRightSubtree(Decl *D);
    DeclSequence* GetRightmostDeclSequenceNode();
    virtual void accept(Visitor *v);
};

#endif