#include "ForStmt.hh"

void ForStmt::accept(Visitor *v)
{
    v->visit(this);
}