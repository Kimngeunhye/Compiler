#include "IntExpr.hh"

void IntExpr::accept(Visitor *v)
{
    v->visit(this);
}

int IntExpr::GetValue()
{
    return astIL->GetValue();
}