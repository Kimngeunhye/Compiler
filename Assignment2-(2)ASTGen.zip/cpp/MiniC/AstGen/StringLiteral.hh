#ifndef __STRING_LITERAL_H__
#define __STRING_LITERAL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Terminal.hh"
#include <string>

using namespace std;

class StringLiteral: public Terminal
{
public:
    StringLiteral (string Lexeme, SourcePos pos):Terminal(pos){
        this->Lexeme = Lexeme;
    }
    virtual void accept(Visitor *v);
};

#endif