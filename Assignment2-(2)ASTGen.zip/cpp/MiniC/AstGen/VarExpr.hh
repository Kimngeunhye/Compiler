#ifndef __VAR_EXPR_H__
#define __VAR_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "IDentifier.hh"

class VarExpr: public Expr
{
public:
    IDentifier *Ident;
    VarExpr (IDentifier *Ident, SourcePos pos):Expr(pos){
        this->Ident = Ident;
    }
    virtual void accept(Visitor *v);
};

#endif