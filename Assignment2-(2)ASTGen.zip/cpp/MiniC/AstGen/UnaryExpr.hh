#ifndef __UNARY_EXPR_H__
#define __UNARY_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Operator.hh"

class UnaryExpr: public Expr
{
public:
    Expr *eAST;
    Operator *oAST;
    UnaryExpr (Operator *oAST, Expr *eAST, SourcePos pos):Expr(pos){
        this->oAST = oAST;
        this->eAST = eAST;
    }
    virtual void accept(Visitor *v);
};

#endif