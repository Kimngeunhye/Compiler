#ifndef __CALL_STMT_H__
#define __CALL_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Stmt.hh"
#include "Expr.hh"

class CallStmt: public Stmt
{
public:
    Expr *eAST;
    CallStmt(Expr *eAST, SourcePos pos):Stmt(pos){
        this->eAST = eAST;
    }
    virtual void accept(Visitor *v);
};

#endif