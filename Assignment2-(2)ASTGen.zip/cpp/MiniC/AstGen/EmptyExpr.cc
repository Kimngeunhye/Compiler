#include "EmptyExpr.hh"

void EmptyExpr::accept(Visitor *v)
{
    v->visit(this);
}