#ifndef __TYPE_H__
#define __TYPE_H__

#include "../Scanner/SourcePos.hh"
#include "AST.hh"

class Type: public AST
{
public:
    Type (SourcePos pos):AST(pos){}

    virtual bool Tequal(Type *t)=0;
    virtual bool AssignableTo(Type *t)=0;
};

#endif