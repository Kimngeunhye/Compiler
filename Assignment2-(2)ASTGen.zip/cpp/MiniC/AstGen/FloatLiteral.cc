#include "FloatLiteral.hh"

void FloatLiteral::accept(Visitor *v)
{
    v->visit(this);
}