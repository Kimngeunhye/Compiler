#ifndef __INT_LITERAL_H__
#define __INT_LITERAL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Terminal.hh"

#include <string>

using namespace std;

class IntLiteral: public Terminal
{
public:   
    int value;
    IntLiteral (string Lexeme, SourcePos pos):Terminal(pos){
        this->Lexeme = Lexeme;
        this->value = stoi(Lexeme);
    }
    virtual void accept(Visitor *v);
    int GetValue();
};

#endif