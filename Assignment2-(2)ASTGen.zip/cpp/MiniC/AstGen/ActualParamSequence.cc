#include "ActualParamSequence.hh"

void ActualParamSequence::accept(Visitor *v)
{
    v->visit(this);
}
