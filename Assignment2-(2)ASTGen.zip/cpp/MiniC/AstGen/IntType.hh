#ifndef __INT_TYPE_H__
#define __INT_TYPE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Type.hh"

class IntType: public Type
{
public:
    IntType (SourcePos pos):Type(pos){}
    virtual void accept(Visitor *v);
    bool Tequal(Type *t);
    bool AssignableTo(Type *t);
};

#endif