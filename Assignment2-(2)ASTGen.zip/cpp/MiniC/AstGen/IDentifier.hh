#ifndef __ID_H__
#define __ID_H__

#include "../Scanner/SourcePos.hh"
#include "Terminal.hh"
#include "Visitor.hh"

using namespace std;

class IDentifier: public Terminal
{
public:
    AST *declAST;
    IDentifier (string Lexeme, SourcePos pos):Terminal(pos){
        this->Lexeme = Lexeme;
        this->declAST = nullptr;
    };
    virtual void accept(Visitor *v);
};

#endif