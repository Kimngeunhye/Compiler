#include "CompoundStmt.hh"

void CompoundStmt::accept(Visitor *v)
{
    v->visit(this);
}