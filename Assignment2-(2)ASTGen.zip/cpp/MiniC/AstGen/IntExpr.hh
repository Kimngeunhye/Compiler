#ifndef __INT_EXPR_H__
#define __INT_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "IntLiteral.hh"

class IntExpr: public Expr
{
public:
    IntLiteral *astIL; 
    IntExpr (IntLiteral *astIL, SourcePos pos):Expr(pos){
        this->astIL = astIL;
    }
    virtual void accept(Visitor *v);
    int GetValue();
};

#endif