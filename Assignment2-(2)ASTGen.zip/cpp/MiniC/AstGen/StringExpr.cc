#include "StringExpr.hh"

void StringExpr::accept(Visitor *v)
{
    v->visit(this);
}