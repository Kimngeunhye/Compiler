#include "IDentifier.hh"

void IDentifier::accept(Visitor *v)
{
    v->visit(this);
}