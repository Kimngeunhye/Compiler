#include "FormalParamDecl.hh"

void FormalParamDecl::accept(Visitor *v)
{
    v->visit(this);
}