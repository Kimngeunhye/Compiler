#include "EmptyDecl.hh"

void EmptyDecl::accept(Visitor *v)
{
    v->visit(this);
}