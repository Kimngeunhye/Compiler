#include "CallStmt.hh"

void CallStmt::accept(Visitor *v)
{
    v->visit(this);
}