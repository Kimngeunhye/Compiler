#ifndef __ACTUALPARAMSEQ_H__
#define __ACTUALPARAMSEQ_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class ActualParamSequence: public Expr
{
public:
    Expr *lAST, *rAST;
    ActualParamSequence (Expr* lAST, Expr* rAST, SourcePos pos):Expr(pos){
        this->lAST = lAST;
        this->rAST = rAST;
    };
    virtual void accept(Visitor *v);
};

#endif