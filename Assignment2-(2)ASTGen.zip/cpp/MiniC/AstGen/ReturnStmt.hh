#ifndef __RETURN_STMT_H__
#define __RETURN_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Stmt.hh"

class ReturnStmt: public Stmt
{
public:
    Expr *eAST;
    ReturnStmt (Expr *eAST, SourcePos pos):Stmt(pos){this->eAST = eAST;}
    virtual void accept(Visitor *v);
};

#endif