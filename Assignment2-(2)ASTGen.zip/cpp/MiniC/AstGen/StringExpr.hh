#ifndef __STRING_EXPR_H__
#define __STRING_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "StringExpr.hh"

class StringExpr: public Expr
{
public:
    StringLiteral *astSL;
    StringExpr (StringLiteral *astSL, SourcePos pos):Expr(pos){
        this->astSL = astSL;
    }
    virtual void accept(Visitor *v);
};

#endif