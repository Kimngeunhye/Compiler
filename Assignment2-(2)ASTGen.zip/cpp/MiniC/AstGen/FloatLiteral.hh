#ifndef __FLOAT_LITERAL_H__
#define __FLOAT_LITERAL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Terminal.hh"
#include <string>

using namespace std;

class FloatLiteral: public Terminal
{
public:
    FloatLiteral(string Lexeme, SourcePos pos):Terminal(pos){
        this->Lexeme = Lexeme;
    }
    virtual void accept(Visitor *v);
};

#endif