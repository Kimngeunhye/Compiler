#ifndef __EMPTY_COMPOUND_STMT_H__
#define __EMPTY_COMPOUND_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "CompoundStmt.hh"

class EmptyCompoundStmt: public CompoundStmt
{
public:
    EmptyCompoundStmt(SourcePos pos):CompoundStmt(nullptr, nullptr, pos){}
    virtual void accept(Visitor *v);
};

#endif