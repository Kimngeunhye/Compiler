#include "AST.hh"

AST::AST (SourcePos pos)
{
    this->pos = new SourcePos();
    this->pos->StartCol = pos.StartCol;
    this->pos->EndCol = pos.EndCol;
    this->pos->StartLine = pos.StartLine;
    this->pos->EndLine = pos.EndLine;
}

SourcePos AST::getPosition()
{
    return *(this->pos);
}