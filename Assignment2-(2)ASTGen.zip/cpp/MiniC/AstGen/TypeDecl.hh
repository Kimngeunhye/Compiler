#ifndef __TYPE_DECL_H__
#define __TYPE_DECL_H__

#include "../Scanner/SourcePos.hh"
#include "Decl.hh"
#include "Type.hh"

class TypeDecl: public Decl
{
public:
    Type*   tAST;
    TypeDecl (Type *tAST, SourcePos pos):Decl(pos){
        this->tAST = tAST;
    }
    void accept(Visitor *v){
        v->visit(this);
    }
};

#endif