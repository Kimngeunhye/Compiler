#ifndef __BINARY_EXPR_H__
#define __BINARY_EXPR_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Operator.hh"

class BinaryExpr: public Expr
{
public:
    Expr *lAST, *rAST;
    Operator *oAST;
    BinaryExpr (Expr *lAST, Operator *oAST, Expr *rAST, SourcePos pos):Expr(pos)
    {
        this->lAST = lAST;
        this->rAST = rAST;
        this->oAST = oAST;
    }
    virtual void accept(Visitor *v);
};

#endif