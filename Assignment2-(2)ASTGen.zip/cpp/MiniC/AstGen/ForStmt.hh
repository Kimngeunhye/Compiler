#ifndef __FOR_STMT_H__
#define __FOR_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Stmt.hh"

class ForStmt: public Stmt
{
public:
    Expr *e1AST, *e2AST, *e3AST;
    Stmt *stmtAST;
    ForStmt (Expr *e1AST, Expr *e2AST, Expr *e3AST, Stmt *stmtAST, SourcePos pos):Stmt(pos){
        this->e1AST = e1AST;
        this->e2AST = e2AST;
        this->e3AST = e3AST;
        this->stmtAST = stmtAST;
    }
    virtual void accept(Visitor *v);
};

#endif