#include "UnaryExpr.hh"

void UnaryExpr::accept(Visitor *v)
{
    v->visit(this);
}