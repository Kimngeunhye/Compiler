#ifndef __TERMINAL_H__
#define __TERMINAL_H__

#include "../Scanner/SourcePos.hh"
#include "AST.hh"
#include <string>

using namespace std;

class Terminal: public AST
{
public:
    string Lexeme;
    Terminal(SourcePos pos):AST(pos){};
};

#endif