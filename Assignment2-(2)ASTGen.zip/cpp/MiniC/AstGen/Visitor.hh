#ifndef __VISITOR_H__
#define __VISITOR_H__

#include <typeinfo>

//#include "VisitorList.hh"

class Program;
class FunDecl;
class EmptyDecl;
class VarDecl;
class FormalParamDecl;
class FormalParamDeclSequence;
class EmptyFormalParamDecl;
class DeclSequence;

class AssignStmt;
class IfStmt;
class WhileStmt;
class ForStmt;
class ReturnStmt;
class CompoundStmt;
class EmptyCompoundStmt;
class EmptyStmt;
class StmtSequence;
class CallStmt;

class VarExpr;
class AssignExpr;
class IntExpr;
class FloatExpr;
class BoolExpr;
class ArrayExpr;
class StringExpr;
class BinaryExpr;
class UnaryExpr;
class EmptyExpr;
class ActualParam;
class EmptyActualParam;
class ActualParamSequence;
class CallExpr;
class ExprSequence;
class IDentifier;
class Operator;
class IntLiteral;
class FloatLiteral;
class BoolLiteral;
class StringLiteral;
class IntType;
class FloatType;
class BoolType;
class VoidType;
class StringType;
class ArrayType;
class ErrorType;
class TypeDecl;

class Visitor
{
public:
  // Program...
  virtual void visit(Program *x)=0;

  // ... and other bits and pieces...
  virtual void visit(EmptyDecl *x)=0;
  virtual void visit(FunDecl *x)=0;

  virtual void visit(VarDecl *x)=0;
  virtual void visit(FormalParamDecl *x)=0;
  virtual void visit(FormalParamDeclSequence *x)=0;
  virtual void visit(EmptyFormalParamDecl *x)=0;
  virtual void visit(DeclSequence *x)=0;

  virtual void visit(AssignStmt *x)=0;
  virtual void visit(IfStmt *x)=0;
  virtual void visit(WhileStmt *x)=0;
  virtual void visit(ForStmt *x)=0;
  virtual void visit(ReturnStmt *x)=0;
  virtual void visit(CompoundStmt *x)=0;
  virtual void visit(EmptyCompoundStmt *x)=0;
  virtual void visit(EmptyStmt *x)=0;
  virtual void visit(StmtSequence *x)=0;
  virtual void visit(CallStmt *x)=0;

  virtual void visit(VarExpr *x)=0;
  virtual void visit(AssignExpr *x)=0;
  virtual void visit(IntExpr *x)=0;
  virtual void visit(FloatExpr *x)=0;
  virtual void visit(BoolExpr *x)=0;
  virtual void visit(ArrayExpr *x)=0;
  virtual void visit(StringExpr *x)=0;
  virtual void visit(BinaryExpr *x)=0;
  virtual void visit(UnaryExpr *x)=0;
  virtual void visit(EmptyExpr *x)=0;
  virtual void visit(ActualParam *x)=0;
  virtual void visit(EmptyActualParam *x)=0;
  virtual void visit(ActualParamSequence *x)=0;
  virtual void visit(CallExpr *x)=0;
  virtual void visit(ExprSequence *x)=0;
  virtual void visit(IDentifier *x)=0;
  virtual void visit(Operator *x)=0;
  virtual void visit(IntLiteral *x)=0;
  virtual void visit(FloatLiteral *x)=0;
  virtual void visit(BoolLiteral *x)=0;
  virtual void visit(StringLiteral *x)=0;
  virtual void visit(IntType *x)=0;
  virtual void visit(FloatType *x)=0;
  virtual void visit(BoolType *x)=0;
  virtual void visit(VoidType *x)=0;
  virtual void visit(StringType *x)=0;
  virtual void visit(ArrayType *x)=0;
  virtual void visit(ErrorType *x)=0;
  virtual void visit(TypeDecl *x)=0;
};

#endif