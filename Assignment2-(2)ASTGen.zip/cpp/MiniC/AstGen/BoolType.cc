#include "BoolType.hh"
#include <iostream>

using namespace std;

void BoolType::accept(Visitor *v)
{
    v->visit(this);
}

bool BoolType::Tequal(Type *t) {
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && typeid(t) == typeid(BoolType*));
}

bool BoolType::AssignableTo (Type *t) {
    //BoolType assignable to t ?
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && (typeid(t) == typeid(BoolType*)));
}