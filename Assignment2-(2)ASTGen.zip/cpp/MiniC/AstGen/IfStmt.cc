#include "IfStmt.hh"

void IfStmt::accept(Visitor *v)
{
    v->visit(this);
}