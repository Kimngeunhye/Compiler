#include "CallExpr.hh"

void CallExpr::accept(Visitor *v)
{
    v->visit(this);
}