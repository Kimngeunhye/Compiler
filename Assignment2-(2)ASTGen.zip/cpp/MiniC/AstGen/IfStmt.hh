#ifndef __IF_STMT_H__
#define __IF_STMT_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"
#include "Stmt.hh"

class IfStmt: public Stmt
{
public:
    Expr *eAST;
    Stmt *thenAST, *elseAST;
    IfStmt (Expr *eAST, Stmt *thenAST, SourcePos pos):Stmt(pos){
        this->eAST = eAST;
        this->thenAST = thenAST;
        this->elseAST = nullptr;   
    }
    IfStmt (Expr *eAST, Stmt *thenAST, Stmt *elseAST, SourcePos pos):Stmt(pos){
        this->eAST = eAST;
        this->thenAST = thenAST;
        this->elseAST = elseAST;
    }
    virtual void accept(Visitor *v);
};

#endif