#include "Operator.hh"

void Operator::accept(Visitor *v)
{
    v->visit(this);
}