#ifndef __VOID_TYPE_H__
#define __VOID_TYPE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Type.hh"

class VoidType: public Type
{
public:
    VoidType (SourcePos pos):Type(pos){}
    virtual void accept(Visitor *v);
    bool Tequal(Type *t);
    bool AssignableTo(Type *t);
};

#endif