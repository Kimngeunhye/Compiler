#include "VarDecl.hh"

void VarDecl::accept(Visitor *v)
{
    v->visit(this);
}