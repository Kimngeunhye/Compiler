#include "ArrayType.hh"    

void ArrayType::accept(Visitor *v)
{
    v->visit(this);
}

bool ArrayType::Tequal (Type *t)
{
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return false;
}

bool ArrayType::AssignableTo (Type *t)
{
    assert (t != nullptr);
    if (typeid(t) == typeid(ArrayType*)){
        // Arrays we consider "assignable" if they have the same
        // element type and the same size.
        ArrayType *arrT = (ArrayType*)t;
        bool eTypeSame = this->astType->Tequal(arrT->astType);
        return eTypeSame && (arrT->GetRange() == this->GetRange());
    }
    return false;
}

int ArrayType::GetRange()
{
    assert (typeid(astExpr) == typeid(IntExpr*));
    return ((IntExpr*)astExpr)->GetValue();
}