#include "VoidType.hh"
#include <iostream>

using namespace std;

void VoidType::accept(Visitor *v)
{
    v->visit(this);
}

bool VoidType::Tequal(Type *t)
{
    if (t != nullptr && typeid(t) == typeid(ErrorType*))
        return true;
    else
        return (t != nullptr && typeid(t) == typeid(VoidType*));
}

bool VoidType::AssignableTo(Type *t)
{
    return false;
}