#include "EmptyFormalParamDecl.hh"

void EmptyFormalParamDecl::accept(Visitor *v)
{
    v->visit(this);
}