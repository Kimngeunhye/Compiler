#include "BinaryExpr.hh"

void BinaryExpr::accept(Visitor *v)
{
    v->visit(this);
}