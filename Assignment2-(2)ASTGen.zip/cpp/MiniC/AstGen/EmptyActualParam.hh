#ifndef __EMPTY_ACTUAL_PARAM_H__
#define __EMPTY_ACTUAL_PARAM_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Expr.hh"

class EmptyActualParam: public Expr
{
public:
    EmptyActualParam(SourcePos pos):Expr(pos){};
    virtual void accept(Visitor *v);
};

#endif