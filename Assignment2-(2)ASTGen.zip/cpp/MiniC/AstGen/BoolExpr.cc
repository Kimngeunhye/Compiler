#include "BoolExpr.hh"

void BoolExpr::accept(Visitor *v)
{
    v->visit(this);
}