#ifndef __FUN_DECL_H__
#define __FUN_DECL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Decl.hh"
#include "Type.hh"
#include "IDentifier.hh"
#include "Stmt.hh"

class FunDecl: public Decl
{
public:
    Type *tAST;
    IDentifier *idAST;
    Decl *paramsAST;
    Stmt *stmtAST;

    FunDecl (Type *tAST, IDentifier *idAST, Decl *paramsAST, Stmt *stmtAST, SourcePos pos):Decl(pos){
        this->tAST = tAST;
        this->idAST = idAST;
        this->paramsAST = paramsAST;
        this->stmtAST = stmtAST;
    }
    virtual void accept(Visitor *v);
};

#endif