#include "ExprSequence.hh"

void ExprSequence::accept(Visitor *v)
{
    v->visit(this);
}