#ifndef __FORMAL_PARAM_DECL_H__
#define __FORMAL_PARAM_DECL_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Type.hh"
#include "Decl.hh"
#include "IDentifier.hh"

class FormalParamDecl: public Decl
{
public:
    Type *astType;
    IDentifier *astIdent;
    FormalParamDecl (Type *astType, IDentifier *astIdent, SourcePos pos):Decl(pos){
        this->astType = astType;
        this->astIdent = astIdent;
    }
    virtual void accept(Visitor *v);
};

#endif