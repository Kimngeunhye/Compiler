#ifndef __FORMAL_PARAM_DECL_SEQUENCE_H__
#define __FORMAL_PARAM_DECL_SEQUENCE_H__

#include "Visitor.hh"
#include "../Scanner/SourcePos.hh"
#include "Decl.hh"

class FormalParamDeclSequence: public Decl
{
public:
    Decl *lAST, *rAST;
    FormalParamDeclSequence (Decl *lAST, Decl *rAST, SourcePos pos):Decl(pos){
        this->lAST = lAST;
        this->rAST = rAST;
    }
    virtual void accept(Visitor *v);
};

#endif