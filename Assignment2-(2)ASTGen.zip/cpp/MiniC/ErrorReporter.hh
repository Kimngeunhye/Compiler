#ifndef __ERRORREPORTER_H__
#define __ERRORREPORTER_H__

#include "./Scanner/SourcePos.hh"
#include <string>
#include <iostream>

using namespace std;

class ErrorReporter
{
public:
    static int numErrors;
    ErrorReporter()
    {        
    }

    void reportError(string message, string tokenName, SourcePos pos)
    {
        cout << "ERROR: ";

        for (string::iterator iter = message.begin(); iter != message.end(); ++iter)
        {
            if (*iter == '%')
            {
                cout << tokenName;
            }
            else
            {
                cout << *iter;
            }
        }
        cout << " " << pos.StartCol << ".." << pos.EndCol << ", line " << pos.StartLine << "." << endl;
        this->numErrors++;
    }
};

#endif