#ifndef __DRAWER_H__
#define __DRAWER_H__

#include <opencv4/opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include "../AstGen/VisitorList.hh"
#include "DrawingTree.hh"
#include "LayoutVisitor.hh"

using namespace std;
using namespace cv;

class Drawer
{
private:
    Program     *AST;
    DrawingTree *Drawing;

public:
    Mat image;
    Drawer();
    void draw(Program *ast);
    void paintAST(Mat *g);
};

#endif