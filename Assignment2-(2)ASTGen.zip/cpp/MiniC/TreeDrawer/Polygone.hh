#ifndef __POLYGONE_H__
#define __POLYGONE_H__

#include "Polyline.hh"

class Polygone
{
public:
    Polyline *lower_head, *lower_tail;
    Polyline *upper_head, *upper_tail;
};

#endif