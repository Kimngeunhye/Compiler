#ifndef __POLYGON_H__
#define __POLYGON_H__

#include "Polyline.hh"

class Polygon
{
public:
    Polyline *lower_head, *lower_tail;
    Polyline *upper_head, *upper_tail;
    Polygon(){}
    /*Polygon(const Polygon &copy){
        lower_head = copy.lower_head;
        lower_tail = copy.lower_tail;
        upper_head = copy.upper_head;
        upper_tail = copy.upper_tail;
    }*/
};

#endif