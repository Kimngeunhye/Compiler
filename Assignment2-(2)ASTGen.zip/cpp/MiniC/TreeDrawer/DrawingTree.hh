#ifndef __DRAWING_TREE_H__
#define __DRAWING_TREE_H__

#include <opencv4/opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

#include <string>

#include "Polygon.hh"

using namespace std;
using namespace cv;

class DrawingTree
{
public:
    string      caption;
    int         width, height;
    Point       pos, offset;
    Polygon     *contour;
    DrawingTree *parent;
    DrawingTree **children;
    int         num_child;

    DrawingTree(string caption, int width, int height, int num_child);
    void setChildren(DrawingTree **children);
    void paint(Mat *graphics);
    void position(Point pos);
    int  minx();
    void fix_x(int f);

    int  max_x();
    int  max_y();

};

#endif