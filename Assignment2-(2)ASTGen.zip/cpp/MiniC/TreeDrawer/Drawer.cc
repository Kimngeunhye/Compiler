#include "Drawer.hh"

Drawer::Drawer()
{
    //image = Mat::zeros(1080, 1920, CV_8UC3);
    //rectangle(image, Rect(Point(0,0), Point(1920, 1080)), Scalar(255,255,255), -1);
    
    //imshow("MiniC Compiler AST", image);
    //waitKey( 0 );
}

void Drawer::draw(Program *ast)
{
    AST = ast;
    LayoutVisitor *lv = new LayoutVisitor();
    AST->accept(lv);
    Drawing = lv->Tree;
    Drawing->position(Point(100, 100)); //* Start position
    int minx = Drawing->minx();
    if (minx < 0){
        Drawing->fix_x(-1*minx);
    }

    int maxx = Drawing->max_x();
    int maxy = Drawing->max_y();

    image = Mat::zeros(maxy+100, maxx+100, CV_8UC3);
    rectangle(image, Rect(Point(0,0), Point(maxx+100, maxy+100)), Scalar(255,255,255), -1);

    paintAST(&image);

    namedWindow("MiniC Compiler AST", WINDOW_AUTOSIZE);//WINDOW_NORMAL);
    //resize(drawer->image, drawer->image, Size(drawer->image.cols/2, drawer->image.rows/2));
    imshow("MiniC Compiler AST", image);
    waitKey( 0 );
}

void Drawer::paintAST(Mat *g)
{
    if (Drawing != nullptr)
        Drawing->paint(g);
}