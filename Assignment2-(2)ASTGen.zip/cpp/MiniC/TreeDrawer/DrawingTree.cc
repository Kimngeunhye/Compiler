#include "DrawingTree.hh"

DrawingTree::DrawingTree(string caption, int width, int height, int num_child)
{
    this->caption   = caption;
    this->width     = width;
    this->height    = height;
    this->parent    = nullptr;
    this->children  = nullptr;
    this->pos       = Point(0, 0);
    this->offset    = Point(0, 0);
    this->contour   = new Polygon();
    this->num_child = num_child;
}

void DrawingTree::setChildren(DrawingTree **children)
{
    this->children = children;
    for (int i = 0; i < num_child; i++)
    {
        children[i]->parent = this;
    }
}

void DrawingTree::paint(Mat *graphics)
{
    rectangle(*graphics, Point(pos.x, pos.y), Point(pos.x+width, pos.y+height), Scalar(0,0,0), 1);
    putText(*graphics, caption.c_str(), Point(pos.x+2, pos.y + (height+10)/2), FONT_HERSHEY_PLAIN, 1, Scalar(0,0,0), 1);
    
    if (children != nullptr)
    {
        for (int i = 0; i < num_child; i++)
        {
            children[i]->paint(graphics);
        }
    }

    if (parent != nullptr)
    {
        line(
            *graphics,
            Point(int(pos.x + width / 2), pos.y),
            Point(int(parent->pos.x + parent->width / 2), parent->pos.y + parent->height),
            Scalar(0, 0, 0), 1
        );
    }
}

void DrawingTree::position(Point pos)
{
    this->pos.x = pos.x + offset.x;
    this->pos.y = pos.y + offset.y;

    Point temp = Point(this->pos.x, this->pos.y);
    if (children != nullptr)
    {
        for (int i = 0; i < num_child; i++)
        {
            children[i]->position(temp);
            temp.x += children[i]->offset.x;
            temp.y = this->pos.y + children[0]->offset.y;
        }
    }
}

int DrawingTree::minx()
{
    int t;
    int minx = pos.x;

    if (children != nullptr) {
      for (int i = 0; i < num_child; i++) {
        t = children[i]->minx();
        if(t < minx) {
            minx = t;
        }
      }
    }
    return minx;
}

void DrawingTree::fix_x(int f)
{
    pos.x += f;
    if (children != nullptr)
    {
        for (int i = 0; i < num_child; i++){
            children[i]->fix_x(f);
        }
    }
}

int DrawingTree::max_x()
{
    int t;
    int max_x = pos.x;

    if (children != nullptr) {
      for (int i = 0; i < num_child; i++) {
        t = children[i]->max_x();
        if(t > max_x) {
            max_x = t;
        }
      }
    }
    return max_x;
}

int DrawingTree::max_y()
{
    int t;
    int max_y = pos.y;

    if (children != nullptr) {
      for (int i = 0; i < num_child; i++) {
        t = children[i]->max_y();
        if(t > max_y) {
            max_y = t;
        }
      }
    }
    return max_y;
}