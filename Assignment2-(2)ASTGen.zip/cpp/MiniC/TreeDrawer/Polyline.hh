#ifndef __POLYLINE_H__
#define __POLYLINE_H__

class Polyline
{
public:
    int         dx, dy;
    Polyline    *link;

    Polyline(int dx, int dy, Polyline *link)
    {
        this->dx = dx;
        this->dy = dy;
        this->link = link;
    }
    /*
    Polyline(const Polyline &copy)
    {
        this->dx = copy.dx;
        this->dy = copy.dy;
        this->link = copy.link;
    }
    */
};

#endif