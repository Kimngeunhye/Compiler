#include "LayoutVisitor.hh"

LayoutVisitor::LayoutVisitor(){
    this->IsGlobal = true;
    this->TypeInfo = true; // TBD: make this a constructor argument!
}

string LayoutVisitor::TypeTag(Type *t)
{
    string l = "";
    if (t == nullptr) {
        l = "<?>";
    } else if (t->Tequal(stdenv->intType)) {
        l = "<int>";
    } else if (t->Tequal(stdenv->boolType)) {
        l = "<bool>";
    } else if (t->Tequal(stdenv->floatType)) {
        l = "<float>";
    } else if (t->Tequal(stdenv->stringType)) {
        l = "<string>";
    } else if (t->Tequal(stdenv->voidType)) {
        l = "<void>";
    } else if (typeid(t) == typeid(ArrayType*)) {
        l = "<array>";
    } else if (typeid(t) == typeid(ErrorType*)) { //->Tequal(stdenv->errorType)) {
        l = "<error>";
    } else {
        assert(false);
    }
    return l;
}

void LayoutVisitor::visit(Program *x){
    Tree = layoutUnary("Program", x->D);
}

void LayoutVisitor::visit(EmptyDecl *x){
    Tree = layoutNullary("EmptyDecl");
}

void LayoutVisitor::visit(FunDecl *x){
    IsGlobal = false;
    Tree = layoutQuaternary("FunDecl", x->tAST, x->idAST, x->paramsAST, x->stmtAST);
    IsGlobal = true;
}

void LayoutVisitor::visit(TypeDecl *x){
    Tree = layoutUnary("TypeDecl", x->tAST);
}

void LayoutVisitor::visit(FormalParamDecl *x){
    Tree = layoutBinary("FormalParamDecl", x->astType, x->astIdent);
}

void LayoutVisitor::visit(FormalParamDeclSequence *x){
    Tree = layoutBinary("FormalParamDeclSeq", x->lAST, x->rAST);
    
}

void LayoutVisitor::visit(EmptyFormalParamDecl *x){
    Tree = layoutNullary("EmptyFormalParamDecl");
}

void LayoutVisitor::visit(StmtSequence *x){
    Tree = layoutBinary("StmtSeq", x->s1AST, x->s2AST);
}

void LayoutVisitor::visit(AssignStmt *x){
    Tree = layoutBinary("AssignStmt", x->lAST, x->rAST);
}

void LayoutVisitor::visit(IfStmt *x){
    if (x->elseAST == nullptr) {
      Tree = layoutBinary("IfStmt", x->eAST, x->thenAST);
    } else { 
      Tree = layoutTernary("IfStmt", x->eAST, x->thenAST, x->elseAST);
    }
}

void LayoutVisitor::visit(WhileStmt *x){
    Tree = layoutBinary ("WhileStmt", x->eAST, x->stmtAST);
}

void LayoutVisitor::visit(ForStmt *x){
    Tree = layoutQuaternary("ForStmt", x->e1AST, x->e2AST, x->e3AST, x->stmtAST);
}

void LayoutVisitor::visit(ReturnStmt *x){
    Tree = layoutUnary ("ReturnStmt", x->eAST);
}

void LayoutVisitor::visit(CompoundStmt *x){
    Tree = layoutBinary("CompoundStmt", x->astDecl, x->astStmt);
}

void LayoutVisitor::visit(EmptyStmt *x){
    Tree = layoutNullary("EmptyStmt");
}

void LayoutVisitor::visit(EmptyCompoundStmt *x){
    Tree = layoutNullary("EmptyCompoundStmt");
}

void LayoutVisitor::visit(CallStmt *x){
    Tree = layoutUnary ("CallStmt", x->eAST);
}

void LayoutVisitor::visit(VarDecl *x){
    string l = "VarDecl";
    if (IsGlobal) {
      l = "G." + l; 
    } else {
      l = "L." + l;
    }
    Tree = layoutTernary(l, x->tAST, x->idAST, x->eAST);
}

void LayoutVisitor::visit(DeclSequence *x){
    Tree = layoutBinary("DeclSeq", x->D1, x->D2);
}

void LayoutVisitor::visit(VarExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("VarExpr" + l, x->Ident);
}

void LayoutVisitor::visit(AssignExpr *x){
    Tree = layoutBinary("AssignExpr", x->lAST, x->rAST);
}

void LayoutVisitor::visit(IntExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("IntExpr" + l, x->astIL);
}

void LayoutVisitor::visit(FloatExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("FloatExpr" + l, x->astFL);
}

void LayoutVisitor::visit(BoolExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("BoolExpr" + l, x->astBL);
}

void LayoutVisitor::visit(StringExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("StringExpr" + l, x->astSL);
}

void LayoutVisitor::visit(ArrayExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutBinary("ArrayExpr" + l, x->idAST, x->indexAST);
}

void LayoutVisitor::visit(BinaryExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutTernary("BinaryExpr" + l, x->lAST, x->oAST, x->rAST);
}

void LayoutVisitor::visit(UnaryExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutBinary("UnaryExpr" + l, x->oAST, x->eAST);
}

void LayoutVisitor::visit(EmptyExpr *x){
    Tree = layoutNullary("EmptyExpr");
}

void LayoutVisitor::visit(ActualParam *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutUnary("ActualParam" + l, x->pAST);
}

void LayoutVisitor::visit(EmptyActualParam *x){
    Tree = layoutNullary("EmptyActualParam");
}

void LayoutVisitor::visit(ActualParamSequence *x){
    Tree = layoutBinary("ActualParamSeq", x->lAST, x->rAST);
}

void LayoutVisitor::visit(CallExpr *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutBinary("CallExpr" + l, x->idAST, x->paramAST);
}

void LayoutVisitor::visit(ExprSequence *x){
    Tree = layoutBinary("ExprSeq", x->lAST, x->rAST);
}

void LayoutVisitor::visit(IDentifier *x){
    Tree = layoutNullary(x->Lexeme);
}

void LayoutVisitor::visit(Operator *x){
    string l = "";
    if (TypeInfo){
        l = TypeTag(x->type);
    }
    Tree = layoutNullary(x->Lexeme + l);
}

void LayoutVisitor::visit(IntLiteral *x){
    Tree = layoutNullary(x->Lexeme);
}

void LayoutVisitor::visit(FloatLiteral *x){
    Tree = layoutNullary(x->Lexeme);
}

void LayoutVisitor::visit(BoolLiteral *x){
    Tree = layoutNullary(x->Lexeme);
}

void LayoutVisitor::visit(StringLiteral *x){
    Tree = layoutNullary(x->Lexeme);
}

void LayoutVisitor::visit(IntType *x){
    Tree = layoutNullary("int");
}

void LayoutVisitor::visit(FloatType *x){
    Tree = layoutNullary("float");
}

void LayoutVisitor::visit(BoolType *x){
    Tree = layoutNullary("bool");
}

void LayoutVisitor::visit(StringType *x){
    Tree = layoutNullary("String");
}

void LayoutVisitor::visit(VoidType *x){
    Tree = layoutNullary("void");
}

void LayoutVisitor::visit(ArrayType *x){
    Tree = layoutBinary("Array", x->astType, x->astExpr);
}

void LayoutVisitor::visit(ErrorType *x){
    Tree = layoutNullary("Error");
}

DrawingTree* LayoutVisitor::layoutCaption (string name)
{
    int w = (name.length())*10 + 5;
    int h = 20; // TODO: it was set as magic number; fix it later.. (it's not a big deal)
    return new DrawingTree(name, w, h, 0);
}

DrawingTree* LayoutVisitor::layoutNullary (string name)
{
    DrawingTree* dt = layoutCaption(name);
    dt->contour->upper_tail = new Polyline(0, dt->height + 2 * BORDER, nullptr);
    dt->contour->upper_head = dt->contour->upper_tail;
    dt->contour->lower_tail = new Polyline(-dt->width - 2 * BORDER, 0, nullptr);
    dt->contour->lower_head = new Polyline(0, dt->height + 2 * BORDER, dt->contour->lower_tail);
    return dt;
}

DrawingTree* LayoutVisitor::layoutUnary (string name, AST *child1)
{
    DrawingTree *dt = layoutCaption(name);
    child1->accept(this);
    DrawingTree *d1 = Tree;

    DrawingTree **tmp = new DrawingTree*[1]; tmp[0] = d1;
    dt->num_child = 1;
    dt->setChildren(tmp);   //dt->setChildren(new DrawingTree[]{d1});
    attachParent(dt, join(dt));
    return dt;
}

DrawingTree* LayoutVisitor::layoutBinary (string name, AST *child1, AST *child2)
{
    //std::cout<<">Binary : "<<name<<std::endl;
    DrawingTree *dt = layoutCaption(name);
    child1->accept(this);
    DrawingTree *d1 = Tree;
    child2->accept(this);
    DrawingTree *d2 = Tree;

    DrawingTree **tmp = new DrawingTree*[2]; tmp[0] = d1; tmp[1] = d2;
    dt->num_child = 2;
    dt->setChildren(tmp);
    attachParent(dt, join(dt));
    return dt;
}

DrawingTree* LayoutVisitor::layoutTernary (string name, AST *child1, AST *child2, AST *child3)
{
    DrawingTree *dt = layoutCaption(name);
    child1->accept(this);
    DrawingTree *d1 = Tree;
    child2->accept(this);
    DrawingTree *d2 = Tree;
    child3->accept(this);
    DrawingTree *d3 = Tree;

    DrawingTree **tmp = new DrawingTree*[3]; tmp[0] = d1; tmp[1] = d2; tmp[2] = d3;
    dt->num_child = 3;
    dt->setChildren(tmp);
    attachParent(dt, join(dt));
    return dt;
}

DrawingTree* LayoutVisitor::layoutQuaternary (string name, AST *child1, AST *child2, AST *child3, AST *child4)
{
    DrawingTree *dt = layoutCaption(name);
    child1->accept(this);
    DrawingTree *d1 = Tree;
    child2->accept(this);
    DrawingTree *d2 = Tree;
    child3->accept(this);
    DrawingTree *d3 = Tree;
    child4->accept(this);
    DrawingTree *d4 = Tree;

    DrawingTree **tmp = new DrawingTree*[4]; tmp[0] = d1; tmp[1] = d2; tmp[2] = d3; tmp[3] = d4;
    dt->num_child = 4;
    dt->setChildren(tmp);
    attachParent(dt, join(dt));
    return dt;
}

void LayoutVisitor::attachParent (DrawingTree *dt, int w)
{
    int y = PARENT_SEP;
    int x2 = (w - dt->width) / 2 - BORDER;
    int x1 = x2 + dt->width + 2 * BORDER - w;

    dt->children[0]->offset.y = y + dt->height;
    dt->children[0]->offset.x = x1;

    dt->contour->upper_head = new Polyline(0, dt->height, new Polyline(x1, y, dt->contour->upper_head));
    dt->contour->lower_head = new Polyline(0, dt->height, new Polyline(x2, y, dt->contour->lower_head));
}

int LayoutVisitor::join (DrawingTree *dt)
{
    int w, sum;

    dt->contour = dt->children[0]->contour;
    w = dt->children[0]->width + 2 * BORDER;
    sum = w;

    for (int i=1; i<dt->num_child; i++)
    {
        int d = merge(dt->contour, dt->children[i]->contour);
        dt->children[i]->offset.x = d + w;
        dt->children[i]->offset.y = 0;
        w = dt->children[i]->width + 2 * BORDER;
        sum += d + w;
    }
    return sum;
}

int LayoutVisitor::merge(Polygon *c1, Polygon *c2)
{
    int x, y, total, d;
    Polyline *lower, *upper, *b;

    x = 0; y = 0; total = 0;
    upper = c1->lower_head;
    lower = c2->upper_head;

    while (lower != nullptr && upper != nullptr){
        d = offset(x, y, lower->dx, lower->dy, upper->dx, upper->dy);
        x += d;
        total += d;

        if (y + lower->dy <= upper->dy) {
            x += lower->dx;
            y += lower->dy;
            lower = lower->link;
        } else {
            x -= upper->dx;
            y -= upper->dy;
            upper = upper->link;
        }
    }

    if (lower != nullptr)
    {
        b = bridge(c1->upper_tail, 0, 0, lower, x, y);
        c1->upper_tail = (b->link != nullptr) ? c2->upper_tail : b;
        c1->lower_tail = c2->lower_tail;
    }
    else
    {
        b = bridge(c2->lower_tail, x, y, upper, 0, 0);
        if (b->link == nullptr)
        {
            c1->lower_tail = b;
        }
    }
    c1->lower_head = c2->lower_head;

    return total;
}

int LayoutVisitor::offset (int p1, int p2, int a1, int a2, int b1, int b2)
{
    int d, s, t;

    if (b2 <= p2 || p2 + a2 <= 0)
        return 0;
    
    t = b2 * a1 - a2 * b1;
    if (t > 0) {
        if (p2 < 0) {
            s = p2 * a1;
            d = s / a2 - p1;
        } else if (p2 > 0) {
            s = p2 * b1;
            d = s / b2 - p1;
        } else {
            d = -p1;
        }
    } else if (b2 < p2 + a2) {
        s = (b2 - p2) * a1;
        d = b1 - (p1 + s / a2);
    } else if (b2 > p2 + a2) {
        s = (a2 + p2) * b1;
        d = s / b2 - (p1 + a1);
    } else {
        d = b1 - (p1 + a1);
    }

    if (d > 0) {
        return d;
    } else {
        return 0;
    }
}

Polyline* LayoutVisitor::bridge (Polyline *line1, int x1, int y1, Polyline *line2, int x2, int y2)
{
    int dy, dx, s;
    Polyline *r;

    dy = y2 + line2->dy - y1;
    if (line2->dy == 0) {
        dx = line2->dx;
    } else {
        s = dy * line2->dx;
        dx = s / line2->dy;
    }

    r = new Polyline(dx, dy, line2->link);
    line1->link = new Polyline(x2 + line2->dx - dx - x1, 0, r);

    return r;

}
