#ifndef __LAYOUT_VISITOR_H__
#define __LAYOUT_VISITOR_H__

#include "../AstGen/VisitorList.hh"
#include "../Scanner/SourcePos.hh"
#include "DrawingTree.hh"
#include "../AstGen/AST.hh"
#include "../StdEnvironment.hh"

#include <cassert>

using namespace std;

#define BORDER      5
#define PARENT_SEP  30

class LayoutVisitor: public Visitor
{
public:
    DrawingTree     *Tree;
    bool            draw_pos;
    bool            IsGlobal;
    bool            TypeInfo; // true if we include type information in the AST.
    StdEnvironment* stdenv;

    LayoutVisitor();

    string          TypeTag(Type *t);
    
    //string          FormatPosition(SourcePos pos);
    DrawingTree*    layoutNullary (string name);
    DrawingTree*    layoutCaption(string name);
    DrawingTree*    layoutUnary(string name, AST *child1);
    DrawingTree*    layoutBinary (string name, AST *child1, AST *child2);
    DrawingTree*    layoutTernary(string name, AST *child1, AST *child2, AST *child3);
    DrawingTree*    layoutQuaternary(string name, AST *child1, AST *child2, AST *child3, AST *child4);
    void            attachParent(DrawingTree *dt, int w);
    int             join(DrawingTree *dt);
    int             merge(Polygon *c1, Polygon *c2);
    int             offset(int p1, int p2, int a1, int a2, int b1, int b2);
    Polyline*       bridge(Polyline *line1, int x1, int y1, Polyline *line2, int x2, int y2);

    virtual void visit(Program *x);
    virtual void visit(EmptyDecl *x);
    virtual void visit(FunDecl *x);
    virtual void visit(VarDecl *x);
    virtual void visit(FormalParamDecl *x);
    virtual void visit(FormalParamDeclSequence *x);
    virtual void visit(EmptyFormalParamDecl *x);
    virtual void visit(DeclSequence *x);
    virtual void visit(AssignStmt *x);
    virtual void visit(IfStmt *x);
    virtual void visit(WhileStmt *x);
    virtual void visit(ForStmt *x);
    virtual void visit(ReturnStmt *x);
    virtual void visit(CompoundStmt *x);
    virtual void visit(EmptyCompoundStmt *x);
    virtual void visit(EmptyStmt *x);
    virtual void visit(StmtSequence *x);
    virtual void visit(CallStmt *x);
    virtual void visit(VarExpr *x);
    virtual void visit(AssignExpr *x);
    virtual void visit(IntExpr *x);
    virtual void visit(FloatExpr *x);
    virtual void visit(BoolExpr *x);
    virtual void visit(ArrayExpr *x);
    virtual void visit(StringExpr *x);
    virtual void visit(BinaryExpr *x);
    virtual void visit(UnaryExpr *x);
    virtual void visit(EmptyExpr *x);
    virtual void visit(ActualParam *x);
    virtual void visit(EmptyActualParam *x);
    virtual void visit(ActualParamSequence *x);
    virtual void visit(CallExpr *x);
    virtual void visit(ExprSequence *x);
    virtual void visit(IDentifier *x);
    virtual void visit(Operator *x);
    virtual void visit(IntLiteral *x);
    virtual void visit(FloatLiteral *x);
    virtual void visit(BoolLiteral *x);
    virtual void visit(StringLiteral *x);
    virtual void visit(TypeDecl *x);
    virtual void visit(IntType *x);
    virtual void visit(FloatType *x);
    virtual void visit(BoolType *x);
    virtual void visit(VoidType *x);
    virtual void visit(StringType *x);
    virtual void visit(ArrayType *x);
    virtual void visit(ErrorType *x);
};

#endif