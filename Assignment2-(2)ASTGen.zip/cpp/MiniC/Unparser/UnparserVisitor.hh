#ifndef __UNPARSER_VISITOR_H__
#define __UNPARSER_VISITOR_H__

#include "../AstGen/VisitorList.hh"
#include "../Scanner/SourcePos.hh"
#include <iostream>
#include <fstream>

using namespace std;

#define INDENT_LEVEL 3 //amount of indentation per level

class UnparseVisitor: public Visitor
{
private:
    ofstream    *out;
    int         indent;
    void        newline();
    void        write(string s);
public:
    bool        IsGlobal;
    bool        IsFirst;
    
    UnparseVisitor(ofstream *out);

    virtual void visit(Program *x);
    virtual void visit(EmptyDecl *x);
    virtual void visit(FunDecl *x);
    virtual void visit(VarDecl *x);
    virtual void visit(FormalParamDecl *x);
    virtual void visit(FormalParamDeclSequence *x);
    virtual void visit(EmptyFormalParamDecl *x);
    virtual void visit(DeclSequence *x);
    virtual void visit(AssignStmt *x);
    virtual void visit(IfStmt *x);
    virtual void visit(WhileStmt *x);
    virtual void visit(ForStmt *x);
    virtual void visit(ReturnStmt *x);
    virtual void visit(CompoundStmt *x);
    virtual void visit(EmptyCompoundStmt *x);
    virtual void visit(EmptyStmt *x);
    virtual void visit(StmtSequence *x);
    virtual void visit(CallStmt *x);
    virtual void visit(VarExpr *x);
    virtual void visit(AssignExpr *x);
    virtual void visit(IntExpr *x);
    virtual void visit(FloatExpr *x);
    virtual void visit(BoolExpr *x);
    virtual void visit(ArrayExpr *x);
    virtual void visit(StringExpr *x);
    virtual void visit(BinaryExpr *x);
    virtual void visit(UnaryExpr *x);
    virtual void visit(EmptyExpr *x);
    virtual void visit(ActualParam *x);
    virtual void visit(EmptyActualParam *x);
    virtual void visit(ActualParamSequence *x);
    virtual void visit(CallExpr *x);
    virtual void visit(ExprSequence *x);
    virtual void visit(IDentifier *x);
    virtual void visit(Operator *x);
    virtual void visit(IntLiteral *x);
    virtual void visit(FloatLiteral *x);
    virtual void visit(BoolLiteral *x);
    virtual void visit(StringLiteral *x);
    virtual void visit(TypeDecl *x);
    virtual void visit(IntType *x);
    virtual void visit(FloatType *x);
    virtual void visit(BoolType *x);
    virtual void visit(VoidType *x);
    virtual void visit(StringType *x);
    virtual void visit(ArrayType *x);
    virtual void visit(ErrorType *x);
};

#endif