#include "UnparserVisitor.hh"

UnparseVisitor::UnparseVisitor(ofstream *out)
{
    this->out = out;
    indent = 0;
    IsGlobal = true;
    IsFirst = true;
}

void UnparseVisitor::newline()
{
    int i;
    write("\n");
    for (i = 1; i <= indent*INDENT_LEVEL; i++)
        write(" ");
}

void UnparseVisitor::write(string s)
{
    (*out) << s;
}

void UnparseVisitor::visit(Program *x) {
    SourcePos pos;
    if (typeid(x->D) != typeid(new EmptyDecl(pos))) {
        x->D->accept(this);
    }
    write("\n");
}

void UnparseVisitor::visit(EmptyDecl *x) {
    assert (false);
}

void UnparseVisitor::visit(FunDecl *x) {
    SourcePos pos;
    if (!IsFirst) {
        newline();
        newline();
    }
    IsFirst = false;
    IsGlobal = false;
    x->tAST->accept(this);
    write(" ");
    x->idAST->accept(this);
    write("(");
    if (typeid(x->paramsAST) == typeid(new FormalParamDeclSequence(nullptr, nullptr, pos))) {
        x->paramsAST->accept(this);
    }
    write(")");
    x->stmtAST->accept(this);
    IsGlobal = true;
}

void UnparseVisitor::visit(FormalParamDecl *x) {
    SourcePos pos;
    if (typeid(x->astType) == typeid(new ArrayType(nullptr, nullptr, pos))) {
        ((ArrayType*)x->astType)->astType->accept(this);
        write (" ");
        x->astIdent->accept(this);
        write("[");
        ((ArrayType*)x->astType)->astExpr->accept(this);
        write("]");
    } else {
        x->astType->accept(this);
        write(" ");
        x->astIdent->accept(this);
    }
}

void UnparseVisitor::visit(FormalParamDeclSequence *x) {
    SourcePos pos;
    x->lAST->accept(this);
    if (typeid(x->rAST) == typeid(new FormalParamDeclSequence(nullptr, nullptr, pos))) {
        write(", ");
        x->rAST->accept(this);
    }
}

void UnparseVisitor::visit(EmptyFormalParamDecl *x) {
    assert (false);
}

void UnparseVisitor::visit(StmtSequence *x) {
    SourcePos pos;
    x->s1AST->accept(this);
    if (typeid(x->s2AST) == typeid(new StmtSequence(nullptr, nullptr, pos))) {
        x->s2AST->accept(this);
    }
}

void UnparseVisitor::visit(AssignStmt *x) {
    newline();
    x->lAST->accept(this);
    write (" = ");
    x->rAST->accept(this);
    write (";");
}

void UnparseVisitor::visit(IfStmt *x) {
    SourcePos pos;
    newline();
    write("if (");
    x->eAST->accept(this);
    write(")");
    if(!(typeid(x->thenAST) == typeid(new CompoundStmt(nullptr, nullptr, pos)))) {
        indent++;
    }
    x->thenAST->accept(this);
    if(!(typeid(x->thenAST) == typeid(new CompoundStmt(nullptr, nullptr, pos)))) {
        indent--;
    }
    if(x->elseAST != nullptr) {
        newline();
        write("else");
        if(!(typeid(x->elseAST) == typeid(new CompoundStmt(nullptr, nullptr, pos)))) {
            indent++;
        }
        x->elseAST->accept(this);
        if(!(typeid(x->elseAST) == typeid(new CompoundStmt(nullptr, nullptr, pos)))) {
            indent--;
        }
    }
}

void UnparseVisitor::visit(WhileStmt *x) {
    newline();
    write ("while (");
    x->eAST->accept(this);
    write(")");
    x->stmtAST->accept(this);
}

void UnparseVisitor::visit(ForStmt *x) {
    SourcePos pos;
    newline();
    write ("for (");
    if (typeid(x->e1AST) == typeid(new EmptyExpr(pos))) {
        x->e1AST->accept(this);
    }
    write(";");
    if(!(typeid(x->e2AST) == typeid(new EmptyExpr(pos)))) {
        write(" ");
        x->e2AST->accept(this);
    }
    write(";");
    if(!(typeid(x->e3AST) == typeid(new EmptyExpr(pos)))) {
        write(" ");
        x->e3AST->accept(this);
    }
    write(")");
    x->stmtAST->accept(this);
}

void UnparseVisitor::visit(ReturnStmt *x) {
    SourcePos pos;
    newline();
    write("return");
    if (!(typeid(x->eAST) == typeid(new EmptyExpr(pos)))) {
        write (" ");
        x->eAST->accept(this);
    }
    write(";");
}

void UnparseVisitor::visit(CompoundStmt *x) {
    SourcePos pos;
    newline();
    write("{");
    indent++;
    if (typeid(x->astDecl) == typeid(new DeclSequence(nullptr, nullptr, pos))) {
        x->astDecl->accept(this);
    }
    if (typeid(x->astStmt) == typeid(new StmtSequence(nullptr, nullptr, pos))) {
        x->astStmt->accept(this);
    }
    indent--;
    newline();
    write("}");
}

void UnparseVisitor::visit(EmptyCompoundStmt *x) {
    newline();
    write("{}");
}

void UnparseVisitor::visit(EmptyStmt *x) {
    assert (false);
}

void UnparseVisitor::visit(CallStmt *x) {
    newline();
    x->eAST->accept(this);
    write(";");
}

void UnparseVisitor::visit(VarDecl *x) {
    SourcePos pos;
    if (IsGlobal && !IsFirst) {
        newline();
        newline();
    } else if (!IsGlobal && !IsFirst) {
        newline();
    }
    IsFirst = false;
    if (typeid(x->tAST) == typeid(new ArrayType(nullptr, nullptr, pos))) {
        ((ArrayType*)x->tAST)->astType->accept(this);
        write (" ");
        x->idAST->accept(this);
        write("[");
        ((ArrayType*)x->tAST)->astExpr->accept(this);
        write("]");
        if (typeid(x->eAST) == typeid(new ExprSequence(nullptr, nullptr, pos)))
        {
            write(" = { ");
            x->eAST->accept(this);
            write(" }");
        } 
        else if (typeid(x->eAST) != typeid(new EmptyExpr(pos)))
        {
            write(" = ");
            x->eAST->accept(this);
        }
    } else {
        x->tAST->accept(this);
        write (" ");
        x->idAST->accept(this);
        if (typeid(x->eAST) == typeid(new ExprSequence(nullptr, nullptr, pos)))
        {
            write(" = { ");
            x->eAST->accept(this);
            write(" }");
        }
        else if (typeid(x->eAST) != typeid(new EmptyExpr(pos)))
        {
            write(" = ");
            x->eAST->accept(this);
        }
    }
    write(";");
}

void UnparseVisitor::visit(DeclSequence *x){
    SourcePos pos;
    x->D1->accept(this);
    if (typeid(x->D2) == typeid(new DeclSequence(nullptr, nullptr, pos))) {
        x->D2->accept(this);
    }
}

void UnparseVisitor::visit(VarExpr *x) {
    x->Ident->accept(this);
}

void UnparseVisitor::visit(AssignExpr *x) {
    x->lAST->accept(this);
    write (" = ");
    x->rAST->accept(this);
}

void UnparseVisitor::visit(IntExpr *x) {
    x->astIL->accept(this);
}

void UnparseVisitor::visit(FloatExpr *x) {
    x->astFL->accept(this);
}

void UnparseVisitor::visit(BoolExpr *x) {
    x->astBL->accept(this);
}

void UnparseVisitor::visit(StringExpr *x) {
    x->astSL->accept(this);
}

void UnparseVisitor::visit(ArrayExpr *x) {
    x->idAST->accept(this);
    write("[");
    x->indexAST->accept(this);
    write("]");
}

void UnparseVisitor::visit(BinaryExpr *x) {
    write("(");
    x->lAST->accept(this);
    write(" ");
    x->oAST->accept(this);
    write(" ");
    x->rAST->accept(this);
    write(")");
}

void UnparseVisitor::visit(UnaryExpr *x) {
    write("(");
    x->oAST->accept(this);
    x->eAST->accept(this);
    write(")");
}

void UnparseVisitor::visit(EmptyExpr *x) {
    assert (false);
}

void UnparseVisitor::visit(ActualParam *x) {
    x->pAST->accept(this);
}

void UnparseVisitor::visit(EmptyActualParam *x) {
    assert (false);
}

void UnparseVisitor::visit(ActualParamSequence *x) {
    SourcePos pos;
    x->lAST->accept(this);
    if (typeid(x->rAST) == typeid(new ActualParamSequence(nullptr, nullptr, pos))) {
        write(", ");
        x->rAST->accept(this);
    }
}

void UnparseVisitor::visit(CallExpr *x) {
    SourcePos pos;
    x->idAST->accept(this);
    write("(");
    if (typeid(x->paramAST) == typeid(new ActualParamSequence(nullptr, nullptr, pos))) {
        x->paramAST->accept(this);
    }
    write(")");
}

void UnparseVisitor::visit(ExprSequence *x) {
    SourcePos pos;
    x->lAST->accept(this);
    if (typeid(x->rAST) == typeid(new ExprSequence(nullptr, nullptr, pos))) {
        write(", ");
        x->rAST->accept(this);
    }
}

void UnparseVisitor::visit(IDentifier *x) {
    write(x->Lexeme);
}

void UnparseVisitor::visit(Operator *x) {
    write(x->Lexeme);
} 

void UnparseVisitor::visit(IntLiteral *x) {
    write(x->Lexeme);
} 

void UnparseVisitor::visit(FloatLiteral *x) {
    write(x->Lexeme);
} 

void UnparseVisitor::visit(BoolLiteral *x) {
    write(x->Lexeme);
} 

void UnparseVisitor::visit(StringLiteral *x) {
    write("\"" + x->Lexeme + "\"");
} 

void UnparseVisitor::visit(IntType *x) {
    write ("int");
}

void UnparseVisitor::visit(FloatType *x) {
    write ("float");
}

void UnparseVisitor::visit(BoolType *x) {
    write ("bool");
}

void UnparseVisitor::visit(StringType *x) {
    assert(false);
}

void UnparseVisitor::visit(VoidType *x) {
    write ("void");
}

void UnparseVisitor::visit(ArrayType *x) {
    assert(false); //never called directly.
}

void UnparseVisitor::visit(ErrorType *x) {
    write ("ErrorType");
}

void UnparseVisitor::visit(TypeDecl *x) {
    assert(false);  // only occurs in the StdEnvironment AST!
    //x->tAST->accept(this);
}