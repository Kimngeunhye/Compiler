#ifndef __UNPARSER_H__
#define __UNPARSER_H__

#include "../AstGen/VisitorList.hh"
#include "UnparserVisitor.hh"
#include <fstream>
#include <string>

using namespace std;

class Unparser
{
public:
    Unparser(){}
    void unparse(Program *ast, string FileName);
};

#endif