#include "Unparser.hh"

void Unparser::unparse(Program *ast, string FileName)
{
    ofstream out;
    out.open(FileName);
    
    //Create an UnparseVisitor and visit the AST:
    UnparseVisitor *uv = new UnparseVisitor(&out);
    ast->accept(uv);
    //Close the output stream
    out.close();
}