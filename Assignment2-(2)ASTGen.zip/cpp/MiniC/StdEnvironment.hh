#ifndef __STD_ENVIRONMENT_H__
#define __STD_ENVIRONMENT_H__

#include "Scanner/SourcePos.hh"
#include "AstGen/VisitorList.hh"

class StdEnvironment
{
public:
    // The pre-defined language environment for MiniC:

    // ASTs representing the MiniC standard type declarations:
    TypeDecl *intTypeDecl, *boolTypeDecl, *floatTypeDecl,
             *stringTypeDecl, *voidTypeDecl, *errorTypeDecl;
    
    // ASTs representing the MiniC standard types:
    Type     *intType, *boolType, *floatType, *stringType, *voidType, *errorType;


    // ASTs representing the declarations of our pre-defined MiniC functions:
    FunDecl  *getInt, *putInt, *getBool, *putBool, *getFloat, *putFloat;
    FunDecl  *getString, *putString;
    FunDecl  *putLn;

    Program  *AST;
    SourcePos dummyPos;

    StdEnvironment();
};

#endif