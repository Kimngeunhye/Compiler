#include <iostream>
#include <string>

#include "Scanner/Scanner.hh"
#include "Parser/Parser.hh"
#include "Parser/SyntaxError.hh"
#include "AstGen/AST.hh"
#include "AstGen/VisitorList.hh"
#include "TreePrinter/Printer.hh"
#include "Unparser/Unparser.hh"
#include "TreeDrawer/Drawer.hh"
#include "SemanticAnalysis/SemanticAnalysis.hh"
#include "StdEnvironment.hh"

#include <string>

using namespace std;

Scanner 			*scanner;
Parser				*parser;
SemanticAnalysis	*sem;
ErrorReporter		*reporter;
Drawer				*drawer;
Printer				*printer;
Unparser			*unparser;
StdEnvironment		*stdenv;
/* The abstract syntax tree representing
* the source program:
*/
Program				*AST;

//commandline args:
string		sourceName;
bool		DrawTree1, DrawTree2, DrawTreePlusPos, DrawStdEnvTree, PrintTree, UnparseTree;
string		PrintTreeF, UnparseTreeF;

int Token::overall_nrtokens = 0;
int ErrorReporter::numErrors = 0;
int SourcePos::StartCol = 0; int SourcePos::EndCol = 0;
int SourcePos::StartLine = 0; int SourcePos::EndLine = 0;

void usage();
void processCmdLine(char** argv, int num);

int main(int argc, char** argv)
{
	processCmdLine(argv, argc);
	SourceFile source(sourceName);

	cout << "********** " << "MiniC Compiler" << " **********" << endl;

	scanner = new Scanner(&source);
    /*
     * Enable this to observe the sequence of tokens
     * delivered by the scanner:
     *
     */
	//scanner->enableDebugging();
	reporter	= new ErrorReporter();
	stdenv		= new StdEnvironment();
	parser		= new Parser(scanner, reporter);
	sem			= new SemanticAnalysis(reporter, stdenv);
	drawer		= new Drawer();
	printer		= new Printer();
	unparser	= new Unparser();
	
	
	if (DrawStdEnvTree)
	{
		Drawer *envdrawer = new Drawer();
		envdrawer->draw(stdenv->AST);
	}
	
	cout << "Syntax Analysis ..." << endl;
	AST = parser->parse();		// 1st pass

	
	if (reporter->numErrors == 0){
		if (PrintTree){
			printer->print(AST, PrintTreeF);
		}
		if (UnparseTree){
			unparser->unparse(AST, UnparseTreeF);
		}
		if (DrawTree1){
			drawer->draw(AST);
		}
		cout << "Semantic Analysis ..." << endl;
		sem->check(AST);	// 2nd pass
		if (DrawTree2){
			drawer->draw(AST);
		}
	}

	bool successful = (reporter->numErrors == 0);

	if (successful){
		std::cout << "Compilation was successful." << std::endl;
	}
	else {
		std::cout << "Compilation was unsuccessful." << std::endl;
	}
	return 0;
}

void usage()
{
	cout << "Usage: MiniC filename" << endl;
	cout << "Options: -ast1 to draw the AST before semantic analysis" << endl;
	cout << "Options: -ast2 to draw the AST after semantic analysis" << endl;
	cout << "Options: -envast to draw the StdEnvironment AST" << endl;
	cout << "Options: -t <file> to dump the AST to <file>" << endl;
	cout << "Options: -u <file> to unparse the AST to <file>" << endl;
	exit(-1);
}

void processCmdLine(char** argv, int num)
{
	DrawTree1		= false;
	DrawTree2		= false;
	DrawStdEnvTree	= false;
	PrintTree 		= false;
	PrintTreeF 		= "";
	UnparseTree 	= false;
	UnparseTreeF 	= "";
	sourceName = "";

	string args[10];
	for (int i=0; i<num; i++){
		args[i] = string(argv[i]);
	}

	int arg_index = 1;
	while (arg_index < num){
		if (args[arg_index] == "-ast1"){
			DrawTree1 = true;
			arg_index++;
		}
		else if (args[arg_index] == "-ast2"){
			DrawTree2 = true;
			arg_index++;
		}
		else if (args[arg_index] == "-envast"){
			DrawStdEnvTree = true;
			arg_index++;
		}
		else if (args[arg_index] == "-t"){
			PrintTree = true;
			if (num < arg_index + 1){
				usage();
			} else {
				arg_index++;
				PrintTreeF = args[arg_index];
				arg_index++;
			}
		}
		else if (args[arg_index] == "-u"){
			UnparseTree = true;
			if (num < arg_index + 1){
				usage();
			}
			else{
				arg_index++;
				UnparseTreeF = args[arg_index];
				arg_index++;
			}
		}
		else {
			sourceName = args[arg_index];
			arg_index++;
			if (arg_index < num){
				// After the input source file no arg is allowed:
				usage();
			}
		}
	}
	if (sourceName == ""){
		usage();
	}
}