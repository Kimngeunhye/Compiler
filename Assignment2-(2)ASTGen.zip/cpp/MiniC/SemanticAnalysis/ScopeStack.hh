#ifndef __SCOPE_STACK_H__
#define __SCOPE_STACK_H__

#include "../AstGen/VisitorList.hh"
#include "IdEntry.hh"
#include <string>
#include <cassert>

using namespace std;

class ScopeStack
{
private:
    int         level;
    IdEntry*    latest;
public:
    ScopeStack(){
        level = 1;          //  MiniC's global scope is on level 1.
        latest = nullptr;
    }
    void    openScope();
    void    closeScope();
    bool    enter(string id, Decl *declAST);
    Decl*   retrieve(string id);
};

#endif