#include "ScopeStack.hh"

// Opens a new level in the scope stack, 1 higher than the
// current topmost level.
void ScopeStack::openScope()
{
    this->level++;
}

// Closes the topmost level in the scope stack, discarding
// all entries belonging to that level.
void ScopeStack::closeScope()
{
    IdEntry *entry;

    // Presumably, idTable.level > 0:
    assert (this->level > 0);
    entry = this->latest;
    while (entry->level == this->level) {
      /*
         local = entry;
         entry = local.previous;
       */
      assert(entry->previous != nullptr);
      entry = entry->previous;
    }
    this->level--;
    this->latest = entry;
}

// Makes a new entry in the scope stack for the given identifier
// and attribute. The new entry belongs to the current level.
// Returns false iff there is already an entry for the
// same identifier at the current level.
bool ScopeStack::enter(string id, Decl *declAST)
{
    IdEntry *entry = this->latest;
    bool    searching = true;

    // Check for duplicate entry ...
    while (searching) {
        if (entry == nullptr || entry->level < this->level)
            searching = false;
        else if (entry->id == id) {
            // duplicate entry dedected:
            return false;
        } else
            entry = entry->previous;
    }

    // "id" does not exist on this scope level, add new entry for "id":...
    entry = new IdEntry(id, declAST, this->level, this->latest);
    this->latest = entry;
    return true;
}

// Finds an entry for the given identifier in the scope stack,
// if any. If there are several entries for that identifier, finds the
// entry at the highest level, in accordance with the scope rules.
// Returns nullptr (null pointer in C++) iff no entry is found.
// Otherwise returns the declAST field of the scope stack entry found.
Decl* ScopeStack::retrieve(string id)
{
    IdEntry *entry;
    Decl    *declAST = nullptr;
    bool    searching = true;

    entry = this->latest;
    while (searching) {
        if (entry == nullptr)
            searching = false;
        else if (entry->id == id) {
            searching = false;
            declAST = entry->declAST;
        } else
            entry = entry->previous;
    }
    return declAST;
}