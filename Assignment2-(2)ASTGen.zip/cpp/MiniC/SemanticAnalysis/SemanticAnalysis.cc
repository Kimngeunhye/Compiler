#include "SemanticAnalysis.hh"
    
    
SemanticAnalysis::SemanticAnalysis(ErrorReporter *reporter, StdEnvironment *stdenv)
{
    this->reporter = reporter;
    this->scopeStack = new ScopeStack ();
    this->stdenv = stdenv;
    // Here we enter the entities from the stdenvonment into the scope stack:
    // The scope stack is on level 1 now (initial setting).
    scopeStack->enter ("int", stdenv->intTypeDecl);
    scopeStack->enter ("bool", stdenv->boolTypeDecl);
    scopeStack->enter ("float", stdenv->floatTypeDecl);
    scopeStack->enter ("void", stdenv->voidTypeDecl);
    scopeStack->enter ("getInt", stdenv->getInt);
    scopeStack->enter ("putInt", stdenv->putInt);
    scopeStack->enter ("getBool", stdenv->getBool);
    scopeStack->enter ("putBool", stdenv->putBool);
    scopeStack->enter ("getFloat", stdenv->getFloat);
    scopeStack->enter ("putFloat", stdenv->putFloat);
    scopeStack->enter ("getString", stdenv->getString);
    scopeStack->enter ("putString", stdenv->putString);
    scopeStack->enter ("putLn", stdenv->putLn);

    // This array of strings contains the error messages that we generate
    // for errors detected during semantic analysis. These messages are
    // output using the ErrorReporter.
    // Example: reporter->reportError(errMsg[0], "", *(new SourcePos()));
    //          will print "ERROR #0: main function is missing".
    errMsg[0] = "#0: main function missing";
    errMsg[1] = "#1: return type of main must be int";

    //defining occurrences of identifiers,
    //for local, global variables and for formal parameters:
    errMsg[2] = "#2: identifier redeclared";
    errMsg[3] = "#3: identifier declared void";
    errMsg[4] = "#4: identifier declared void[]";

    //applied occurrences of identifiers:
    errMsg[5] = "#5: undeclared identifier";

    //assignment statements:
    errMsg[6] = "#6: incompatible types for =";
    errMsg[7] = "#7: invalid lvalue in assignment";

    //expression types:
    errMsg[8] = "#8: incompatible type for return statement";
    errMsg[9] = "#9: incompatible types for binary operator";
    errMsg[10] = "#10: incompatible type for unary operator";

    //scalars:
    errMsg[11] = "#11: attempt to use a function as a scalar";

    //arrays:
    errMsg[12] = "#12: attempt to use scalar/function as an array";
    errMsg[13] = "#13: wrong type for element in array initializer";
    errMsg[14] = "#14: invalid initializer: array initializer for scalar";
    errMsg[15] = "#15: invalid initializer: scalar initializer for array";
    errMsg[16] = "#16: too many elements in array initializer";
    errMsg[17] = "#17: array subscript is not an integer";
    errMsg[18] = "#18: array size missing";

    //functions:
    errMsg[19] = "#19: attempt to reference a scalar/array as a function";

    //conditional expressions:
    errMsg[20] = "#20: \"if\" conditional is not of type boolean";
    errMsg[21] = "#21: \"for\" conditional is not of type boolean";
    errMsg[22] = "#22: \"while\" conditional is not of type boolean";

    //parameters:
    errMsg[23] = "#23: too many actual parameters";
    errMsg[24] = "#24: too few actual parameters";
    errMsg[25] = "#25: wrong type for actual parameter";
}

/*
//
// Prints the name of a class,
// usefull for debugging...
//
void SemanticAnalysis::PrintClassName(AST *t) {
    std::cout << "The class of " << t << " is " << typeid(*t).name() << std::endl;
}
*/

// For FunDecl, VarDecl and FormalParamDecl, this function returns
// the type of the declaration.
// 1) for functions declarations, this is the return type of the function
// 2) for variable declarations, this is the type of the variable
Type* SemanticAnalysis::typeOfDecl(AST *d)
{
    Type *T;
    if (d == nullptr) {
        return stdenv->errorType;
    }
    assert ((typeid(d) == typeid(FunDecl*)) || (typeid(d) == typeid(VarDecl*))
         || (typeid(d) == typeid(FormalParamDecl*)));
    if (typeid(d) == typeid(FunDecl*)) {
        T = ((FunDecl*) d)->tAST;
    } else if (typeid(d) == typeid(VarDecl*)) {
        T = ((VarDecl*) d)->tAST;
    } else {
        T = ((FormalParamDecl*) d)->astType;
    }
    return T;
}

// This function returns the element type of an ArrayType AST node. 
Type* SemanticAnalysis::typeOfArrayType(AST *d)
{
    assert (d != nullptr);
    assert (typeid(d) == typeid(ArrayType*));
    ArrayType *T = (ArrayType*)d;
    return T->astType;
}

// This function returns true, if an operator accepts integer or
// floating point arguments.
//  <int> x <int> -> <sometype>
//  <float> x <float> -> <sometype>
bool SemanticAnalysis::HasIntOrFloatArgs(Operator *op)
{
    return ((op->Lexeme == "+")  ||
            (op->Lexeme == "-")  ||
            (op->Lexeme == "*")  ||
            (op->Lexeme == "/")  ||
            (op->Lexeme == "<")  ||
            (op->Lexeme == "<=") ||
            (op->Lexeme == ">")  ||
            (op->Lexeme == ">=") ||
            (op->Lexeme == "==") ||
            (op->Lexeme == "!="));
}

// This function returns true, if an operator accepts bool arguments.
//  <bool> x <bool> -> <sometype>
bool SemanticAnalysis::HasBoolArgs(Operator *op)
{
    return ((op->Lexeme == "&&")  ||
            (op->Lexeme == "||")  ||
            (op->Lexeme == "!")   ||
            (op->Lexeme == "!=")  ||
            (op->Lexeme == "=="));
}

// This function returns true, if an operator returns a bool value.
//  <sometype> x <sometype> -> bool
bool SemanticAnalysis::HasBoolReturnType(Operator *op)
{
    return ((op->Lexeme == "&&") ||
            (op->Lexeme == "||") ||
            (op->Lexeme == "!")  ||
            (op->Lexeme == "!=") ||
            (op->Lexeme == "==") ||
            (op->Lexeme == "<")  ||
            (op->Lexeme == "<=") ||
            (op->Lexeme == ">")  ||
            (op->Lexeme == ">="));
}

// This function performs coercion of an integer-valued expression e.
// It creates an i2f operator and a unary expression.
// Expression e becomes the expression-AST of this unary expression.
//
//            Expr AST for e <int>
//
// =>
//
//            UnaryExpr <float>
//              |     \
//              |      \
//              |       \
//           i2f<int>   Expr AST for e <int>
//
Expr* SemanticAnalysis::i2f(Expr *e)
{
    Operator *op = new Operator ("i2f", *(new SourcePos()));
    op->type = stdenv->intType;
    UnaryExpr *eAST = new UnaryExpr (op, e, *(new SourcePos()));
    eAST->type = stdenv->floatType;
    return eAST;
}

// Given a function declaration FunDecl, this method returns the number
// of formal parameters. E.g., for the following function
//
//    void foo (int a, bool b){}
//
// the return value will be 2.
// Note: this function assumes the AST tree layout from ``Assignment 2-(1): AstGen``.
int SemanticAnalysis::GetNrOfFormalParams(FunDecl *f)
{
    int NrArgs = 0;
    Decl *D = f->paramsAST;
    assert ((typeid(D) == typeid(EmptyFormalParamDecl*)) ||
            (typeid(D) == typeid(FormalParamDeclSequence*)));
    if(typeid(D) == typeid(EmptyFormalParamDecl*))
        return 0;
    while (typeid(D) == typeid(FormalParamDeclSequence*)) {
        NrArgs++;
        D = ((FormalParamDeclSequence*) D)->rAST;
        assert ((typeid(D) == typeid(EmptyFormalParamDecl*)) ||
                (typeid(D) == typeid(FormalParamDeclSequence*)));
    }
    return NrArgs;
}

// Given a function declaration FunDecl, this method returns the AST for 
// the formal parameter nr (nr is the number of the parameter).
// E.g., for the following function and nr=2,
//
//    void foo (int a, bool b){}
//
// the AST returned will be "bool b".
// Note: this function assumes the AST tree layout from Assignment 2-(1).
FormalParamDecl* SemanticAnalysis::GetFormalParam (FunDecl *f, int nr)
{
    int fArgs = GetNrOfFormalParams(f);
    assert(fArgs >= 0);
    assert (nr <= fArgs);
    FormalParamDeclSequence *S = (FormalParamDeclSequence*)f->paramsAST;
    for (int i = 1; i < nr; i++) {
      assert(typeid(S->rAST) == typeid(FormalParamDeclSequence*));
      S = (FormalParamDeclSequence*)S->rAST;
    }
    assert(typeid(S->lAST) == typeid(FormalParamDecl*));
    return (FormalParamDecl*)S->lAST;
}

// Get the number of actual parameters of a function call expression:
// Similar to GetNrOfFormalParams above.
// Note: this function assumes the AST tree layout from Assignment 2-(1).
int SemanticAnalysis::GetNrOfActualParams(CallExpr *f)
{
    int NrArgs = 0;
    Expr *P = f->paramAST;
    assert ((typeid(P) == typeid(EmptyActualParam*)) ||
            (typeid(P) == typeid(ActualParamSequence*)));
    if (typeid(P) == typeid(EmptyActualParam*))
      return 0;
    while (typeid(P) == typeid(ActualParamSequence*)) {
      NrArgs++;
      P = ((ActualParamSequence*) P)->rAST;
      assert ((typeid(P) == typeid(EmptyActualParam*)) ||
              (typeid(P) == typeid(ActualParamSequence*)));
    }
    return NrArgs;
}

// Given a function call expression, get the actual parameter nr
// (nr is the number of the parameter).
// Similar to GetFormalParam above.
// Note: this function assumes the AST tree layout from Assignment 2-(1).
ActualParam* SemanticAnalysis::GetActualParam(CallExpr *f, int nr)
{
    int aArgs = GetNrOfActualParams(f);
    Expr *P = f->paramAST;
    assert(aArgs >= 0);
    assert (nr <= aArgs);
    for (int i = 1; i < nr; i++) {
        assert(typeid(P) == typeid(ActualParamSequence*));
        P = ((ActualParamSequence*)P)->rAST;
    }
    assert ( typeid(((ActualParamSequence*)P)->lAST) == typeid(ActualParam*) );
    return (ActualParam*) ((ActualParamSequence*)P)->lAST;
}

// Given a type t, this function can be used to print the type.
// Useful for debuggging, a similar mechanism is used in the
// TreeDrawer Visitor.
/*
string TypeTag (Type *t) {
    String l = new String("");
    if (t == nullptr) {
        l = new string("<?>");
    } else if (t->Tequal(stdenvonment.intType)) {
        l = new String ("<int>");
    } else if (t.Tequal(stdenvonment.boolType)) {
        l = new String ("<bool>");
    } else if (t.Tequal(stdenvonment.floatType)) {
        l = new String ("<float>");
    } else if (t.Tequal(stdenvonment.stringType)) {
        l = new String ("<string>");
    } else if (t.Tequal(stdenvonment.voidType)) {
        l = new String ("<void>");
    } else if (t instanceof ErrorType) {
        l = new String ("<error>");
    } else {
        assert(false);
    }
    return l;
}
*/

// Checks whether the source program, represented by its AST, satisfies the
// language's scope rules and type rules.
// Decorates the AST as follows:
//  (a) Each applied occurrence of an identifier or operator is linked to
//      the corresponding declaration of that identifier or operator.
//  (b) Each expression and value-or-variable-name is decorated by its type.
void SemanticAnalysis::check(Program *progAST)
{
    visit(progAST);
    // STEP 3:
    // Check Error 0
    // 
    // Retrieve "main" from the scope stack. If it is not there (null is
    // returned, then the program does not contain a main function.

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(Program *x)
{
    x->D->accept(this);
}

void SemanticAnalysis::visit(EmptyDecl *x)
{    
}

void SemanticAnalysis::visit(FunDecl *x)
{
    currentFunctionReturnType = x->tAST;
    // STEP 1:
    // Enter this function in the scope stack. Return Error 2 if this
    // name is already present in this scope.

    /* Start of your code: */

    /* End of your code */

    // STEP 3:
    // Check Error 1: 
    // If this function is the "main" function, then ensure that
    // x->tAST is of type int.

    /* Start of your code: */

    /* End of your code */

    // STEP 1:
    // Open a new scope in the scope stack. This will be the scope for the
    // function's formal parameters and the function's body.
    // We will close this scope in the visit procedure of this
    // function's compound_stmt.

    /* Start of your code: */

    /* End of your code */


    // The following flag is needed when we visit compound statements {...},
    // to avoid opening a fresh scope for function bodies (because we have
    // already opened one, for the formal parameters).
    IsFunctionBlock = true; // needed in {...}, to avoid opening a fresh scope.

    x->paramsAST->accept(this);
    x->stmtAST->accept(this);
}

void SemanticAnalysis::visit(TypeDecl *x)
{
    assert(false);     // TypeDecl nodes occur only in the stdenvonment AST.
}

void SemanticAnalysis::visit(FormalParamDecl *x)
{
    if (typeid(x->astType) == typeid(ArrayType*)) {
        ((ArrayType*)x->astType)->astExpr->accept(this);
    }
    // STEP 1:
    // Here we visit the declaration of a formal parameter. You should enter
    // the lexeme x.astIdent.Lexeme together with its declaration x into
    // the scope stack. If this name is already present in the current scope,
    // the scope stack enter method will return false. You should report
    // Error 2 in that case.

    /* Start of your code: */

    /* End of your code */

    // STEP 3:
    // Check that the formal parameter is not of type void or void[]. 
    // Report error messages 3 and 4 respectively:

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(FormalParamDeclSequence *x)
{
    x->lAST->accept(this);
    x->rAST->accept(this);
}

void SemanticAnalysis::visit(EmptyFormalParamDecl *x)
{
}

void SemanticAnalysis::visit(StmtSequence *x)
{
    x->s1AST->accept(this);
    x->s2AST->accept(this);
}

void SemanticAnalysis::visit(AssignStmt *x)
{
    x->lAST->accept(this);
    x->rAST->accept(this); 
    //STEP 2:
    // Here we type-check assignment statements
    // Two conditions must be ensured:
    // 1) The type of the right-hand side of the assignment statement
    //    (x->rAST->type) must be assignment-compatible
    //    to the left-hand side of the assignment statement.
    //    You can use x->rAST->type->AssignableTo to test assignment-compatibility
    //    of the type of the left-hand side (x->lAST->type).
    // 2) If 2 types are assignment-compatible, then we need to check
    //    whether a coercion from int to float is needed. You can use
    //    x->lAST->type->Tequal(stdenvonment->floatType) to check whether
    //    the left-hand side is of type float. Check the right-hand side
    //    for type int and use i2f if a coercion is needed. Hint: the return
    //    statement uses a similar mechanism....
    // If conditions (1) or (2) are violated, then you should report Error 6.

    /* Start of your code: */

    /* End of your code */

    if(!(typeid(x->lAST) == typeid(VarExpr*)) && !(typeid(x->lAST) == typeid(ArrayExpr*))) {
        reporter->reportError(errMsg[7], "", *(x->lAST->pos));
    }
}

void SemanticAnalysis::visit(IfStmt *x)
{
    x->eAST->accept(this);
    //STEP 2:
    // Here we are visiting an if statement. If the condition x->eAST->type
    // is not of type bool, we have to issue Error 20. You can have a
    // look at "for" loops, which use a similar check for the loop condition.

    /* Start of your code: */

    /* End of your code */
    x->thenAST->accept(this);
    if(x->elseAST != nullptr) {
      x->elseAST->accept(this);
    }
}

void SemanticAnalysis::visit(WhileStmt *x)
{
    x->eAST->accept(this);
    //STEP 2:
    // Here we are visiting a while statement. If the loop condition
    // is not of type bool, we have to issue Error 22. You can have a
    // look at "for" loops which use a similar check.

    /* Start of your code: */

    /* End of your code */
    x->stmtAST->accept(this);
}

void SemanticAnalysis::visit(ForStmt *x)
{
    x->e1AST->accept(this);
    if(!(typeid(x->e2AST) == typeid(EmptyExpr*))) {
        x->e2AST->accept(this);
        if(!x->e2AST->type->Tequal(stdenv->boolType)) {
            reporter->reportError(errMsg[21], "", *(x->e2AST->pos));
        }
    }
    if(!(typeid(x->e3AST) == typeid(EmptyExpr*))) {
        x->e3AST->accept(this);
    }
    x->stmtAST->accept(this);
}

void SemanticAnalysis::visit(ReturnStmt *x)
{
    // STEP 2:
    // The following code checks assignment-compatibility of the return
    // statement's expression with the return type of the function.
    // Uncomment this code
    // as soon as you have finished type-checking of expressions.
    /* START:
    if (typeid(x->eAST) == typeid(EmptyExpr*)) {
      // ``return;'' requires void function return type:
      if (!currentFunctionReturnType->Tequal(stdenv->voidType)) {
        reporter->reportError(errMsg[8], "", x->eAST->pos);
      }
      return; // done -> early exit
    }
    //
    // Falling through here means x.eAST != EmptyExpr:
    //
    x->eAST->accept(this);
    if(x->eAST->type->AssignableTo(currentFunctionReturnType)) {
      // Check for type coercion: if the function returns float, but
      // the expression of the return statement is of type int, we
      // need to convert this expression to float.
      if(currentFunctionReturnType->Tequal(stdenv->floatType) &&
        x->eAST->type->Tequal(stdenv->intType)) {
        //coercion of operand to int:
        x->eAST = i2f(x->eAST);
      }
    } else {
      reporter->reportError(errMsg[8], "", x->eAST->pos);
    }
    END */
}

void SemanticAnalysis::visit(CompoundStmt *x)
{
    /*
     * If this CompoundStmt is the CompoundStmt of a Function, then
     * we already opened the scope before visiting the formal parameters.
     * No need to open a scope in that case. Otherwise set IsFunctionBlock
     * to false, to remember for nested {...}.
     *
     */
    if (IsFunctionBlock) {
        IsFunctionBlock = false; // nested {...} need to open their own scope.
    } else {
      // STEP 1:
      // Open a new scope for the compound statement (nested block within
      // a function body.

      /* Start of your code: */

      /* End of your code */
    }
    // STEP 1:
    // Invoke the semantic analysis visitor for the declarations and the
    // statements of this CompoundStmt. Hint: look up the file AstGen/CompoundStmt.cc (hh)
    // to learn about the AST children of this node.

    /* Start of your code: */

    /* End of your code */

    // STEP 1:
    // Visiting of this {...} compound statement is done. Close the scope
    // for this compound statement (even if it represents a function body).

    /* Start of your code: */

    /* End of your code */ 
}

void SemanticAnalysis::visit(EmptyStmt *x)
{
    
}

void SemanticAnalysis::visit(EmptyCompoundStmt *x)
{
    // STEP 1:
    // Close this scope if this EmptyCompoundStmt is the body of
    // a function.

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(CallStmt *x)
{
    x->eAST->accept(this);
}

void SemanticAnalysis::visit(VarDecl *x)
{
    if (typeid(x->tAST) == typeid(ArrayType*)) {
        ((ArrayType*)x->tAST)->astExpr->accept(this);
    }
    if (!(typeid(x->eAST) == typeid(EmptyExpr*))) {
        x->eAST->accept(this);
        if (typeid(x->tAST) == typeid(ArrayType*)) {
            //STEP 4:
            //
            // Array declarations.
            // Check for error messages 15, 16, 13.
            // Perform i2f coercion if necessary.

            /* Start of your code: */

            /* End of your code */
        } else {
            //STEP 4:
            //
            // Non-array declarations, i.e., scalar variables.
            // Check for error messages 14, 6.
            // Perform i2f coercion if necessary.

            /* Start of your code: */

            /* End of your code */
        }
    }
    //STEP 1:
    // Here we are visiting a variable declaration x.
    // Enter this variable into the scope stack. Like with formal parameters,
    // if an identifier of the same name is already present, then you should
    // report Error 2.

    /* Start of your code: */

    /* End of your code */

    // STEP 3:
    // Check that the variable is not of type void or void[]. 
    // Report error messages 3 and 4 respectively:

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(DeclSequence *x)
{
    x->D1->accept(this);
    x->D2->accept(this);
}

void SemanticAnalysis::visit(VarExpr *x)
{
    x->Ident->accept(this);
    //STEP 2:
    // Here we are visiting a variable expression.
    // Its type is synthesized from the type of the applied occurrence
    // of its identifier. Use "typeid()" to find out whether x->Ident->declAST
    // is a function declaration (FunDecl*). In that case you should report
    // Error 11 and set x.type to the error type from stdenvonment.
    x->type = typeOfDecl (x->Ident->declAST);
    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(AssignExpr *x)
{
    x->lAST->accept(this);
    x->rAST->accept(this);
    if(x->rAST->type->AssignableTo(x->lAST->type)) {
        //check for type coercion:
        if( x->lAST->type->Tequal(stdenv->floatType) &&
            x->rAST->type->Tequal(stdenv->intType)) {
            //coercion of right operand to int:
            x->rAST = i2f(x->rAST);
        }
    } else {
        reporter->reportError(errMsg[6], "", *(x->rAST->pos));
    }
    if(!(typeid(x->lAST) == typeid(VarExpr*)) && !(typeid(x->lAST) == typeid(ArrayExpr*))) {
        reporter->reportError(errMsg[7], "", *(x->lAST->pos));
    }
}

void SemanticAnalysis::visit(IntExpr *x)
{
    //STEP 2:
    // Here we are visiting an integer literal. Set x->type of this
    // AST node to the int type from the standard environment
    // (setEnvir->intType).

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(FloatExpr *x)
{
    //STEP 2:
    // Here we are visiting a float literal. Set x->type of this
    // AST node to the float type from the standard environment
    // (setEnvir->floatType).

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(BoolExpr *x)
{
    //STEP 2:
    // Here we are visiting a bool literal. Set x->type of this
    // AST node to the bool type from the standard environment
    // (stdenv->boolType).

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(StringExpr *x)
{
    //STEP 2:
    // Here we are visiting a string literal. Set x->type of this
    // AST node to the string type from the standard environment
    // (stdenv->stringType).

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(ArrayExpr *x)
{
    x->idAST->accept(this);
    x->indexAST->accept(this);
    if(!x->indexAST->type->Tequal(stdenv->intType)) {
      reporter->reportError(errMsg[17], "", *(x->indexAST->pos));
    }
    VarExpr *VE = (VarExpr*)x->idAST;
    if(!(typeid(typeOfDecl(VE->Ident->declAST)) == typeid(ArrayType*))) {
        reporter->reportError(errMsg[12], "", *(x->pos));
        x->type = stdenv->errorType; 
    } else {
        x->type = typeOfArrayType(x->idAST->type);
    }
}

void SemanticAnalysis::visit(BinaryExpr *x)
{
    x->lAST->accept(this);
    x->oAST->accept(this);
    x->rAST->accept(this);
    if(HasIntOrFloatArgs(x->oAST)) {
        if( x->lAST->type->Tequal(stdenv->intType) &&
            x->rAST->type->Tequal(stdenv->intType)) {
            x->oAST->type = stdenv->intType;
            if (HasBoolReturnType(x->oAST)) {
                x->type = stdenv->boolType;
            } else {
                x->type = stdenv->intType;
        }
        return;
        }
        else if(x->lAST->type->Tequal(stdenv->floatType) &&
                x->rAST->type->Tequal(stdenv->floatType)) {
            x->oAST->type = stdenv->floatType;
            if (HasBoolReturnType(x->oAST)) {
                x->type = stdenv->boolType;
            } else {
                x->type = stdenv->floatType;
            }
            return;
        }
        else if (x->lAST->type->Tequal(stdenv->intType) &&
                 x->rAST->type->Tequal(stdenv->floatType)) {
            //coercion of left operand to float:
            x->lAST = i2f(x->lAST);
            x->oAST->type = stdenv->floatType;
            if (HasBoolReturnType(x->oAST)) {
                x->type = stdenv->boolType;
            } else {
                x->type = stdenv->floatType;
            }
            return;
        }
        else if (x->lAST->type->Tequal(stdenv->floatType) &&
                 x->rAST->type->Tequal(stdenv->intType)) {
            // STEP 2:
            // This code is part of the type checking for binary
            // expressions. In this case,
            // the left-hand operand is float, the right-hand operand is int.
            // We have to type-cast the right operand to float.
            // This is the dual case to "int x float" above.

            /* Start of your code: */

            /* End of your code */
            return;
        }
    }

    if (HasBoolArgs(x->oAST)) {
        if( x->lAST->type->Tequal(stdenv->boolType) &&
            x->rAST->type->Tequal(stdenv->boolType)) {
            x->oAST->type = stdenv->intType; //!!!!!!!!!!!!!!!!!!!!!
            x->type = stdenv->boolType;
            return;
        }
    }

    x->oAST->type = stdenv->errorType;
    x->type = stdenv->errorType;
    if (!((typeid(x->lAST->type) == typeid(ErrorType*)) || (typeid(x->rAST->type) == typeid(ErrorType*))))
    {
        // Error not spurious, because AST children are ok.
        reporter->reportError(errMsg[9], "", *(x->pos));
    }
}

void SemanticAnalysis::visit(UnaryExpr *x)
{
    x->oAST->accept(this);
    x->eAST->accept(this);
    //STEP 2:
    // Here we synthesize the type attribute for a unary operator.
    // x->eAST->type contains the type of the subexpression of this
    // unary operator.
    //
    // If x->eAST is of type int or float, and if oAST is an operator
    // that supports these types, then x->oAST->type and x->type
    // have to be set to x->eAST->type.
    //
    // If x->eAST is of type bool, and if x->oAST is an operator that
    // supports bool, then x->type is bool, but  x->oAST->type is of type
    // int (because of the JVM convention to represent true and false
    // as ints.
    //
    // In all other cases, x->oAST->type and x->type have to be set to
    // errorType, and Error 10 must be reported.
    //
    // You can have a look at visit(BinaryExpr) for a similar, yet
    // slightly more complicated case.

    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(EmptyExpr *x)
{
    
}

void SemanticAnalysis::visit(ActualParam *x)
{
    x->pAST->accept(this);
    x->type = x->pAST->type;
}

void SemanticAnalysis::visit(EmptyActualParam *x)
{
    
}

void SemanticAnalysis::visit(ActualParamSequence *x)
{
    x->lAST->accept(this);
    x->rAST->accept(this);
}

void SemanticAnalysis::visit(CallExpr *x)
{
    //Here we perform semantic analysis of function calls:
    x->type = stdenv->errorType;
    x->idAST->accept(this);
    x->paramAST->accept(this);
    //Retrieve the declaration of x from the scope stack:
    Decl *D = scopeStack->retrieve(x->idAST->Lexeme);
    // STEP 3:
    // Use "typeid()" to find out if D is a FunDecl. If not, report
    // Error 19 and *return*.
    // This check detects cases like
    //  int f; f(22);
    // where f is not a function. 

    /* Start of your code: */

    /* End of your code */
    FunDecl *F = (FunDecl* ) D;
    // STEP 2:
    // Check that the number of formal args from F and the number of actual
    // parameters of the function call x match.
    // Use the functions GetNrOfFormalParams and
    // GetNrOfActualParams from the beginning of this file to retrieve
    // the number of formal and actual parameters.

    /* Start of your code: */

    /* End of your code */

    // STEP 2:
    // Here we check that the types of the formal and actual parameters
    // match (Error 25). This is similar to type-checking the left-hand
    // and right-hand sides of assignment statements. Two steps need
    // to be carried out:
    //
    // (1)
    // Check that types of formal and actual args match: this means that
    // the actual parameter must be assignable to the formal parameter.
    // You can imagine passing an actual parameter to a formal parameter
    // like an assignment statement: formal_par = actual_par.
    //
    // (2)
    // Perform type coercion (int->float) of the *actual* parameter if necessary.
    //

    /* You can use the following code as part of your solution. Uncomment
     * the following code as soon as you have type-checking
     * of expressions working. Uncomment the matching closing parenthesis
     * of the "for" loop also.

     * Start of your code:

     int NrFormalParams = GetNrOfFormalParams(F);
     for (int i = 1; i<= NrFormalParams; i++) {
        FormalParamDecl *Form = GetFormalParam(F, i);
        ActualParam *Act = GetActualParam(x, i);
        Type *FormalT = Form->astType;
        Type *ActualT = Act->pAST->type;
     }
     */
    /* End of your code */

    // If we fall through here, no semantic error occurred -> set the 
    // return type of the call expression to the return type of
    // its function:
    x->type = typeOfDecl(F);
}

void SemanticAnalysis::visit(ExprSequence *x)
{
    x->lAST->accept(this);
    x->rAST->accept(this);
}

void SemanticAnalysis::visit(IDentifier *x)
{
    // STEP 1:
    // Here we look up the declaration of an identifier
    // from the scope stack. If no declaration can be found on the
    // scope stack, you should report Error 5.
    Decl *binding = scopeStack->retrieve(x->Lexeme);
    if (binding != nullptr) {
      x->declAST = binding;
    }
    /* Start of your code: */

    /* End of your code */
}

void SemanticAnalysis::visit(Operator *x)
{
}

void SemanticAnalysis::visit(IntLiteral *x)
{
}

void SemanticAnalysis::visit(FloatLiteral *x)
{
}

void SemanticAnalysis::visit(BoolLiteral *x)
{
}

void SemanticAnalysis::visit(StringLiteral *x)
{
}

void SemanticAnalysis::visit(IntType *x)
{
}

void SemanticAnalysis::visit(FloatType *x)
{
}

void SemanticAnalysis::visit(BoolType *x)
{
}

void SemanticAnalysis::visit(StringType *x)
{    
}

void SemanticAnalysis::visit(VoidType *x)
{
}

void SemanticAnalysis::visit(ArrayType *x)
{    
}

void SemanticAnalysis::visit(ErrorType *x)
{    
}
