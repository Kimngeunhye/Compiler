#ifndef __ID_ENTRY_H__
#define __ID_ENTRY_H__

#include "../AstGen/Decl.hh"
#include <string>

using namespace std;

class IdEntry {
public:
    string    id;
    Decl      *declAST;
    int       level;
    IdEntry   *previous;

    IdEntry (string id, Decl *declAST, int level, IdEntry *previous) {
        this->id = id;
        this->declAST = declAST;
        this->level = level;
        this->previous = previous;
    }
};

#endif