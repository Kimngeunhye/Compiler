#ifndef __SOURCEPOS_H__
#define __SOURCEPOS_H__

class SourcePos {
public:
	static int StartCol, EndCol;
	static int StartLine, EndLine;

	SourcePos()
	{
	}
	
};

#endif