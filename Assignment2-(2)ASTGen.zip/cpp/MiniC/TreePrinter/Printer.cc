#include "Printer.hh"

void Printer::print(Program *ast, string FileName)
{
    //Create File
    ofstream out;
    out.open(FileName);

    //Create a TreePrinterVisitor and visit the AST:
    TreePrinterVisitor pv(&out);
    ast->accept(&pv);

    //Close the output stream
    out.close();

}