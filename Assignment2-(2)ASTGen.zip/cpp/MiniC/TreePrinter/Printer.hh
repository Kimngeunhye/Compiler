#ifndef __PRINTER_H__
#define __PRINTER_H__

#include "../AstGen/VisitorList.hh"
#include "TreePrinterVisitor.hh"
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Printer
{
public:
    Printer(){}
    void print(Program *ast, string FileName);
};

#endif