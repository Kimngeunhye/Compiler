#include "TreePrinterVisitor.hh"

TreePrinterVisitor::TreePrinterVisitor(ofstream *out)
{
    this->out = out;
    indent = 0;
    draw_pos = false;
}

void TreePrinterVisitor::write(string s)
{
    int i;
    for (i = 1; i <= indent * INDENT_LEVEL; i++)
    {
        out->write(" ", 1);
    }
    out->write(s.c_str(), s.length());
}

string TreePrinterVisitor::FormatPosition(AST *n)
{
    if (draw_pos)
    {
        SourcePos pos = n->getPosition();
        return (" "
            + to_string(pos.StartLine)
            + "(" + to_string(pos.StartCol) + ").."
            + to_string(pos.EndLine)
            + "(" + to_string(pos.EndCol) + ")"
            + "\n");
    }
    else
    {
        return "\n";
    }
}

void TreePrinterVisitor::visit(Program *x)
{
    write("Program" + FormatPosition(x));
    indent++;
    x->D->accept(this);
}

void TreePrinterVisitor::visit(EmptyDecl *x)
{
    write("EmptyDecl\n");
}

void TreePrinterVisitor::visit(FunDecl *x)
{
    write("FunDecl" + FormatPosition(x));
    indent++;
    x->tAST->accept(this);
    x->idAST->accept(this);
    x->paramsAST->accept(this);
    x->stmtAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(FormalParamDecl *x)
{
    write("FormalParamDecl" + FormatPosition(x));
    indent++;
    x->astType->accept(this);
    x->astIdent->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(FormalParamDeclSequence *x)
{
    write("FormalParamDeclSequence\n");
    indent++;
    x->lAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(EmptyFormalParamDecl *x)
{
    write("EmptyformalParamDecl\n");
}

void TreePrinterVisitor::visit(StmtSequence *x)
{
    write("StmtSequence\n");
    indent++;
    x->s1AST->accept(this);
    x->s2AST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(AssignStmt *x)
{
    write("AssignStmt" + FormatPosition(x));
    indent++;
    x->lAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(IfStmt *x)
{
    write("IfStmt" + FormatPosition(x));
    indent++;
    x->eAST->accept(this);
    x->thenAST->accept(this);
    if(x->elseAST != nullptr){
        x->elseAST->accept(this);
    }
    indent--;
}

void TreePrinterVisitor::visit(WhileStmt *x)
{
    write("WhileStmt" + FormatPosition(x));
    indent++;
    x->eAST->accept(this);
    x->stmtAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(ForStmt *x)
{
    write("ForStmt" + FormatPosition(x));
    indent++;
    x->e1AST->accept(this);
    x->e2AST->accept(this);
    x->e3AST->accept(this);
    x->stmtAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(ReturnStmt *x)
{
    write("ReturnStmt" + FormatPosition(x));
    indent++;
    x->eAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(CompoundStmt *x)
{
    write("CompoundStmt" + FormatPosition(x));
    indent++;
    x->astDecl->accept(this);
    x->astStmt->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(EmptyCompoundStmt *x)
{
    write("EmptyCompoundStmt\n");
}

void TreePrinterVisitor::visit(EmptyStmt *x)
{
    write("EmptyStmt\n");
}

void TreePrinterVisitor::visit(CallStmt *x)
{
    write("CallStmt" + FormatPosition(x));
    indent++;
    x->eAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(VarDecl* x)
{
    write("VarDecl" + FormatPosition(x));
    indent++;
    x->tAST->accept(this);
    x->idAST->accept(this);
    x->eAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(DeclSequence *x)
{
    write("DeclSequence\n");
    indent++;
    x->D1->accept(this);
    x->D2->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(VarExpr *x)
{
    write("VarExpr" + FormatPosition(x));
    indent++;
    x->Ident->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(AssignExpr *x)
{
    write("AssignExpr" + FormatPosition(x));
    indent++;
    x->lAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(IntExpr *x)
{
    write("IntExpr" + FormatPosition(x));
    indent++;
    x->astIL->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(FloatExpr *x)
{
    write("FloatExpr" + FormatPosition(x));
    indent++;
    x->astFL->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(BoolExpr *x)
{
    write("BoolExpr" + FormatPosition(x));
    indent++;
    x->astBL->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(StringExpr *x)
{
    write("StringExpr" + FormatPosition(x));
    indent++;
    x->astSL->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(ArrayExpr *x)
{
    write("ArrayExpr" + FormatPosition(x));
    indent++;
    x->idAST->accept(this);
    x->indexAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(BinaryExpr *x)
{
    write("BinaryExpr" + FormatPosition(x));
    indent++;
    x->lAST->accept(this);
    x->oAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(UnaryExpr *x)
{
    write("UnaryExpr" + FormatPosition(x));
    indent++;
    x->oAST->accept(this);
    x->eAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(EmptyExpr *x)
{
    write("EmptyExpr\n");
}

void TreePrinterVisitor::visit(ActualParam *x)
{
    write("ActualParam" + FormatPosition(x));
    indent++;
    x->pAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(EmptyActualParam *x)
{
    write("EmptyActualParam\n");
}

void TreePrinterVisitor::visit(ActualParamSequence *x)
{
    write("ActualParamSequence\n");
    indent++;
    x->lAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(CallExpr *x)
{
    write("CallExpr" + FormatPosition(x));
    indent++;
    x->idAST->accept(this);
    x->paramAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(ExprSequence *x)
{
    write("ExprSequence\n");
    indent++;
    x->lAST->accept(this);
    x->rAST->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(IDentifier *x)
{
    write("ID: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(Operator *x)
{
    write("Operator: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(IntLiteral *x)
{
    write("IntLiteral: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(FloatLiteral *x)
{
    write("FloatLiteral: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(BoolLiteral *x)
{
    write("BoolLiteral: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(StringLiteral *x)
{
    write("StringLiteral: " + x->Lexeme + FormatPosition(x));
}

void TreePrinterVisitor::visit(IntType *x)
{
    write("IntType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(FloatType *x)
{
    write("FloatType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(BoolType *x)
{
    write("BoolType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(StringType *x)
{
    write("StringType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(VoidType *x)
{
    write("voidType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(ArrayType *x)
{
    write("ArrayType" + FormatPosition(x));
    indent++;
    x->astType->accept(this);
    x->astExpr->accept(this);
    indent--;
}

void TreePrinterVisitor::visit(ErrorType *x)
{
    write("ErrorType" + FormatPosition(x));
}

void TreePrinterVisitor::visit(TypeDecl *x)
{
    assert(false);  // Can only occur in the StdEnvironment AST!
}