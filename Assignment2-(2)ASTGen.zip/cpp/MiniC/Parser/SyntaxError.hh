#ifndef __SYNTAXERROR_H__
#define __SYNTAXERROR_H__

#include <exception>

class SyntaxError : public std::exception
{
    string message;
public:
    SyntaxError()
    {
        message = "";
    }
    SyntaxError(string s)
    {
        message = s;
    }
    const char* what() const throw()
    {
        return message.c_str();
    }
};

#endif