#ifndef __PARSER_H__
#define __PARSER_H__

#include "../Scanner/Scanner.hh"
#include "../Scanner/SourcePos.hh"
#include "../Scanner/SourceFile.hh"
#include "../Scanner/Token.hh"
#include "../AstGen/VisitorList.hh"
#include "../ErrorReporter.hh"
#include "SyntaxError.hh"

using namespace std;

class Parser{
private:
    Scanner         *scanner;
    ErrorReporter   *errorReporter;
    Token           *currentToken;
    SourcePos       *previousTokenPosition;

public:
    Parser(Scanner *lexer, ErrorReporter *reporter);
    void accept(int tokenExpected);
    void acceptIt();
    void syntaxError(string messageTemplate, string tokenQuoted);
    bool isTypeSpecifier(int token);

    void start(SourcePos pos);
    void finish(SourcePos pos);

    ArrayType*      parseArrayIndexDecl(Type *T, SourcePos All_pos);
    Program*        parse();
    Decl*           parseProgDecls();
    Program*        parseProgram();
    Decl*           parseFunPart(Type *T, IDentifier *Ident, SourcePos pos);
    Decl*           parseParamsList();
    Decl*           parseParameterDecl();
    Decl*           parseDeclarator(Type *T, SourcePos pos);
    DeclSequence*   parseVarPart(Type *T, IDentifier *Ident, SourcePos pos);
    Expr*           parseUnaryExpr();
    Expr*           parsePrimaryExpr();
    Decl*           parseCompoundDecls();
    Stmt*           parseCompoundStmts();
    CompoundStmt*   parseCompoundStmt();
    Expr*           parseArgs();
    Expr*           parseArgList();
    IDentifier*     parseID();
    Type*           parseTypeSpecifier();

    Expr*           parseInitializerList();
    Expr*           parseInitializer();
    Decl*           parseInitDecl(Type *T);
    Decl*           parseVariableDef();
    Expr*           parseExpr();
    Expr*           parseAndExpr();
    Expr*           parseRelExpr();
    Expr*           parseAddExpr();
    Expr*           parseMultExpr();

    Stmt*           parseStmt();
    Stmt*           parseIfStmt();
    Stmt*           parseWhileStmt();
    Stmt*           parseForStmt();
    Expr*           parseAsgExpr();
};

#endif